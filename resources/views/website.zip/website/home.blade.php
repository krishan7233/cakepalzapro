@extends('website.website_app')
@section('content')
<main>
    <style>
        body{
            font-size:100%;
        }
        .card .card-content .card-title{
            margin-bottom: 0;
        }
        .text{
            font-size:17px;
            color:#333333;
        }
        .card .card-content{
            padding: 18px;
            padding: 18px;

        }
        .safe_portn .img_left {
            width:34%;
            float:left;
        }
        .choose_gifts .select-wrapper input.select-dropdown{
            margin-bottom: 0;
            border-bottom: none;
        }

        /*            .safe-delivery > .row > .col.s3{
                        padding:0 0.2% 0;
                    }*/
        .desk_banner img.lazyload {
            max-height: 372px;
        }
        .desk_banner picture {
            text-align: center;
            width: 100%;
            margin: 0 auto;
            float: left;
        }
        .relation_dropdwn{
            margin: 0;
            max-height: 100%;
            overflow-y: auto;
            height: 400px;
        }
        .choose_option {
            margin: 0 0 10px;
            text-align: left;
            padding: 0 0 20px;
            width: 100%;
        }
        .choose_option li{
            font-size: 14px;
            color: #333;
            line-height: 31px;
            padding: 2px 10px;
            width: 100%;
            display: block;
        }
        .choose_option li:first-child {
            display: none;
        }
        .relation_dropdwn select {
            display: none;
        }
        .label_finder span.selected {
            color: #1BA23E !important;
        }
        .label_finder {
            position: relative;
        }
        .label_finder:after{
            content: "";
            width: 40px;
            height: 44px;
            top: 0px;
            right: -10px;
            pointer-events: none;
            background: #FFF url("{{asset('assets/website/groot/2023/03/22/desktop/down-arrow-header.png") no-repeat 10px 12px;
            position: absolute;
        }
        .occasion-cat{
            font-size: 15px;
            color: #666666;
            display: block;
            opacity: 0.9;
        }
        .occasion-text{
            display: block;
            font-size: 24px;
            color: #333;
            line-height: 23px;
            background: #ffffff;
            z-index: 9;
        }
        .rel-cat{
            font-size: 15px;
            color: #666666;
            display: block;
            opacity: 0.9;
        }
        .shop-by-rel-text{
            display: block;
            font-size: 24px;
            color: #333;
            line-height: 23px;
            background: #ffffff;
            z-index: 9;
        }
        .view_all{
            border-radius: 6px;
            border: 1px solid #FF4E84;
            width: 7%!important;
            font-size: 15px;
            text-align: center;
            color: white;
            float: right!important;
            background-color:#FF4E84;
            padding: 7px!important;
        }

        .desktop-left-title{
            padding-bottom:11px!important;
            color:#4D4D4D;
            font-weight:600;
            font-size:15px!important;
            text-align:left;
        }
        .desktop-title{
            padding-bottom:11px!important;
            color:#404040;
            margin:0 auto;
            padding-top:0.9%;
            text-align:center;
            font-size:30px;
            font-weight: 600;
        }
        .swiper-button-next, .swiper-button-prev {
            width: 40px;
            height: 40px;
            background: #fff;
            border-radius: 50%;
            box-shadow: 0 1px 2px rgb(0 0 0 / 30%);
            display:none;
        }
        .swiper-button-next:after, .swiper-button-prev:after {
            line-height:1.8!important;
        }
        :root{
            --swiper-theme-color:#545454;
            --swiper-navigation-size: 22px;
        }

        .padding-vl{
            padding:0 9px 10px!important;

        }
        .padding-v2{
            padding:0 7px 21px!important;
            margin-bottom: 15px!important;
        }
        @media(min-width:930px) and (max-width:1221px){
            .occasion-cat{
                font-size:12px;
            }
            .occasion-text{
                font-size:18px;
            }
            .rel-cat{
                font-size:13px;
            }
            .shop-by-rel-text{
                font-size:19px;
            }
        }

        .img-radius{
            border-radius:7px
        }

        .choose_option li:hover{
            cursor:pointer;
            background-color:#9e9e9e21;
        }
        .padding-f1{
            width:12.5%!important;
            padding: 0 9px 0!important;
        }
        .wrapped-f1{
            text-align: center;
            font-size: 20px;
            color: #333333;
            font-weight: 600;
            margin-top: 9px;
        }
        .rowapd{
            padding: 17px 25px 17px;
        }
        .card-content-mod{
            border-radius:none!important;
            color:#333333;
            font-size:18px;
            text-align: center;
            padding: 8px!important;
        }
        .best_seller_btn{
            background-color: #FF4E84;
            border-radius: 4px;
            width:76%;
            color: #fff;
            padding: 4px 10px 4px;
            display: inline-block;
            box-shadow: 0px 1px 5px #00000029;
        }
        .card-content-mod-up{
            border-bottom-right-radius: 10px;
            border-bottom-left-radius: 10px;
            background-color: #FFFFFF;
            font-size:18px;
            width:100%;
            color:#333333;
            padding: 8px!important;
            display: inline-block;
            box-shadow: 0px 1px 5px #00000029;
        }
        .absoluteposup{
            margin-top: -12px;
            text-align: center;
        }
        .corp_border {
            border-radius : 10px;
        }
        .gif')}}tWrappedText {
            font-weight:700;
            margin:0 auto;
            font-size:35px;
            color:#333333;
            text-align:center;
            padding: 0% 0 1.3%;
            ;
        }
        .view-more-bttn {
            text-align:center;
            background-color:#FF4E84;
            display: inline-flex;
            padding: 7px 17px 7px!important;
            font-size:15px!important;
            border-radius: 4px;
            color:#FFFFFF;
            text-transform: uppercase;
             margin-top: 10px;
        }
        .internationalCountryFont{
        font-weight:600;

        }
        .premiumGifts{
            padding: 0px 25px;
        }
        .imageRadius{
         border-radius: 10px!important;
        }
        .containerOne {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin: 8px 31px;
        }

        .leftOne,
        .rightOne,
        .centerOne {
            flex: 1;
            display: flex;
            flex-direction: column;
            gap: 10px; /* Adjust spacing between images */
        }
           .containerOne img {
               width: 100%;
               max-width: 100%; /* Ensure the image does not exceed its natural size */
               height: auto;
           }
            .tabsOne {
                display: flex;
                margin-bottom: 10px;
            }

            .tabOne {
                flex: 1;
                padding: 10px;
                text-align: center;
                cursor: pointer;
                background-color: #fff;
                border: 1px solid #ccc;
            }

            .tabOne:hover {
                background-color: #fff;
            }

            .content {
                display: none;
            }

            .active {
                display: block;
            }
            .paddingTopImage{
                padding: 8px!important;
                padding-top: 0px!important;
                border-radius: 20px!important;
            }
                    .view_all {
                       border-radius: 4px;
                        border: 1px solid #FF4E84;
                        font-size: 16px;
                        text-align: center;
                        color: white;
                        margin-right: 10px;
                        float: right!important;
                        padding: 4px!important;
                        background-color: #FF4E84;
                        cursor: pointer;
                    }
                    #dynCartAddonsProduct {
                        background: #fff;
                        width: 100%;
                        float: left;
                    }

                    .your-slider-class{
                                   padding: 0px 70px 0px 78px;
                             }

                                     .recently-view-slider{
                                                                            padding: 0px 70px 0px 70px;
                                                                      }
                                                                    .recently-view-slider .slick-initialized .slick-slide{
                                                                        color: #FFF;
                                                                        margin: 0 15px 0 0;
                                                                        display: flex;
                                                                        align-items: center;
                                                                        justify-content: center;
                                                                      }
                                                                     .recently-view-slider .slick-next, .slick-prev{
                                                                        z-index: 5;
                                                                      }
                                                                      .recently-view-slider .slick-next{
                                                                        right: 15px;
                                                                      }
                                                                      .recently-view-slider .slick-prev{
                                                                        left: 15px;
                                                                      }
                                                                      .recently-view-slider .slick-next:before, .slick-prev:before{
                                                                        color: #000;
                                                                        font-size: 26px;
                                                                      }
                                                                      .recently-view-slider .slick-dots{
                                                                      display:none!important;
                                                                      }
                                                                      .recently-view-slider .slick-track {float: left}
                                                                      .recently-view-slider .slick-prev, .slick-next { font-size: 0;line-height: 0;position: absolute;top: 50%; display: block;left:93%; border-radius: 50%;width: 58px;height: 60px; padding: 0;-webkit-transform: translate(0, -50%); -ms-transform: translate(0, -50%); transform: translate(0, -50%); cursor: pointer; color: transparent; border: 1px solid #efefef; outline: none; z-index: 9;}

                                                                      .recently-view-slider .slick-prev {background: rgba(219, 219, 219, 0.5) url("{{asset('assets/website/groot/2023/12/18/desktop/arrow-left.png')}}") no-repeat 11px 11px;background-size: 17px;background-size: 84px!important;background-position: -13px;left: 58px!important;;}
                                                                      .recently-view-slider .slick-next {background: rgba(219, 219, 219, 0.5) url("{{asset('assets/website/groot/2023/12/18/desktop/arrow-right.png')}}") no-repeat 11px 11px; right : 2px;background-size: 84px!important;background-position: -13px;}

                                                                       .recently-view-slider .slick-dots{
                                                                              display:none!important;
                                                                              }
                                     .tabOne.active {
                                         background: #484848;
                                         color: white;
                                     }

                                         .custom-tab {
                                           margin-right: 10px;
                                           padding: 10px;
                                           cursor: pointer;
                                           background-color: #eee;
                                         }

                                         .custom-tab:hover {
                                           background-color: #ddd;
                                         }


                                         .custom-tab-content.active {
                                           display: block;
                                         }
                                         .addColorForPlant{
                                          background: #EFFAED 0% 0% no-repeat padding-box;
                                         }
                                         .addColorForChocolate{
                                          background: #F3EAD9 0% 0% no-repeat padding-box;
                                          }
                                          .addColorForCombos{
                                           background: #FFFAEB 0% 0% no-repeat padding-box;
                                           }
                                               .plantActiveTab{
                                                 background: #484848!important;
                                                 color: white!important;
                                               }
                                               .plantActiveTab{
                                                    background: #484848!important;
                                                    color: white!important;
                                                  }
                                                  .chocolatesActiveTab{
                                                   background: #484848!important;
                                                   color: white!important;
                                                 }
                                                  .combosActiveTab{
                                                    background: #484848!important;
                                                    color: white!important;
                                                  }

                                               .custom-tab-content {
                                                 display: none;
                                               }

                                               .custom-tab-content.active {
                                                 display: block;
                                               }
                                                    .bottomLineDesign::before{
                                                               content: "";
                                                                   display: block;
                                                                   border-bottom: 2px solid #b0b6b9;
                                                                   Width: 93.1%;
                                                                   top: 50px;
                                                                   left: 13px;
                                                                   opacity: 0.4;
                                                                   position: absolute;
                                                         }



.carousel-container {
  position: relative;
  overflow: hidden;
  width: 400px; /* Adjust the width as needed */
  margin: 0 auto;
}

.carousel-wrapper {
  display: flex;
  transition: transform 0.5s ease;
}

.carousel-item {
  flex: 0 0 auto;
  width: 100%;
}

.prev-btn,
.next-btn {
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
  cursor: pointer;
  font-size: 18px;
  font-weight: bold;
  background-color: #333;
  color: #fff;
  border: none;
  padding: 10px;
  margin: 0 5px;
}

.prev-btn {
  left: 0;
}

.next-btn {
  right: 0;
}

.carousel-container {
position: relative;
overflow: hidden;
width: 100%;
margin: 0 auto;
}

.carousel-wrapper {
position: relative;
display: flex;
transition: transform 0.5s ease;
}

.carousel-item {
flex: 0 0 calc(25% - 20px);
margin: 0 10px;
}

.next-btn-click {
position: absolute;
top: 50%;
transform: translateY(-50%);
cursor: pointer;
font-size: 18px;
font-weight: bold;
border: none;
padding: 10px;
margin: 0 5px;
z-index: 1; /* Ensure buttons appear above the carousel items */
}
.prev-btn-click {
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
  cursor: pointer;
  font-size: 18px;
  font-weight: bold;
  border: none;
  padding: 10px;
  margin: 0 5px;
  z-index: 2; /* Increase the z-index value */
}

.prev-btn-click {
left: -58px!important;
}

.next-btn-click {
right: 0;
}
.prev-next-container {
  position: relative;
}
 .allHoursMinutesSecondsDesign{
    line-height:49px;font-family:Open Sans, sans-serif; font-weight:lighter;margin:0;font-size:43px;color:#fafafa;position: relative;
    }
    .hourDesign{
    color:#3f3f3f;padding: 10px;border-radius: 10px;position: absolute;top: -69px;left: 108px;font-size: 13px;font-weight:600;
    }
    .minutesDesign{
     color:#3f3f3f;padding: 10px;border-radius: 10px;position: absolute;top: -69px;font-size: 13px;left: 193px;font-weight:600;
    }
     .secondsDesign{
          color:#3f3f3f;padding: 10px;border-radius: 10px;POSITION: ABSOLUTE;TOP: -69PX;FONT-SIZE: 13PX;font-weight: 600;left: 280px;
        }
        .hourLeftToday{
        color:black;
        font-size: 48px;
        position: absolute;
        top: 24px;
        left: 6px;

        }
        .view_all_trending_button{
         background: #FFE085 0% 0% no-repeat padding-box;
         border: 1px solid #E6E6E6;
         border-radius: 6px;
         color: #22181C;
         text-transform: uppercase;
         padding: 7px!important;
         font-weight: 700;
          width:25%!important;
          text-align:center;
        }
        .view_all_personalised{
        background: #CCE8FF 0% 0% no-repeat padding-box;
        border: 1px solid #E6E6E6;
        border-radius: 6px;
        color: #22181C;
        text-transform: uppercase;
        padding: 7px!important;
        font-weight: 700;
         width:24%!important;
         text-align:center;
        }
        .view_all_multiple{
        background: #E2E2E2 0% 0% no-repeat padding-box;border: 1px solid #E6E6E6;border-radius: 4px;color: #22181C;margin-top: -11px;font-weight:700;padding: 7px 10px!important;
         width:24%!important;
         text-align:center;
        }

                                              .priceOffDesignForDesktop{
                                              font-size:12px!important;
                                               border-radius: 4px!important;
                                               padding-left: 6px!important;
                                               padding-right: 6px!important;
                                               padding-top: 4px!important;
                                               padding-bottom: 4px!important;
                                               }
             .productTextMargin{
                 margin-left: 12px!important;
                     font-size: 14px!important;

             }
             .belowTextSpaceMargin{
              margin-left: 12px!important;
                          font-size: 14px!important;
             }
             .moneySymbolDesign{
              font-size: 12px!important;
              }
              .moneyCalculationDesign{
               font-size: 12px!important;
              }
              .discountMoneyDesign{
               font-size: 12px!important;

              }

@media only screen and (min-width: 1200px) and (max-width: 1500px) {

.hourDesign {
    color: #3f3f3f;
    padding: 10px;
    border-radius: 10px;
    position: absolute;
    top: -77px;
    left: 108px;
    font-size: 11px;
    font-weight: 600;
}
.minutesDesign {
    color: #3f3f3f;
    padding: 10px;
    border-radius: 10px;
    position: absolute;
    top: -76px;
    font-size: 11px;
    left: 172px;
    font-weight: 600;
}

.secondsDesign {
    color: #3f3f3f;
    padding: 10px;
    border-radius: 10px;
    POSITION: ABSOLUTE;
    TOP: -75PX;
    FONT-SIZE: 11PX;
    font-weight: 600;
    left: 238px;
}
  .recently-view-slider .slick-next {background: rgba(219, 219, 219, 0.5) url("{{asset('assets/website/groot/2023/12/18/desktop/arrow-right.png')}}") no-repeat 11px 11px; right : 2px;background-size: 84px!important;background-position: -13px;left: 92%!important;position:absolute; }
              .slick-next slick-arrow{
              left:92.4%!important;
               position:absolute!important;

                               }
                                  .priceOffDesignForDesktop{
                                  font-size:10px!important;
                                   border-radius: 4px!important;
                                   padding-left: 6px!important;
                                   padding-right: 6px!important;
                                   padding-top: 4px!important;
                                   padding-bottom: 4px!important;
                                   }
 .productTextMargin{
     margin-left: 12px!important;
         font-size: 14px!important;

 }
 .belowTextSpaceMargin{
  margin-left: 12px!important;
              font-size: 14px!important;
 }
 .moneySymbolDesign{
  font-size: 11px!important;
  }
  .moneyCalculationDesign{
   font-size: 11px!important;
  }
  .discountMoneyDesign{
   font-size: 10px!important;

  }
 .belowTextSpaceMargin{
          font-size: 14px;
          margin-left: 12px;
 }


.hourLeftToday{
       font-size: 43px!important;
}
.timerDesignForDesktop{
  font-size: 28px!important;
}
.hourLeftToday {
    color: black;
    position: absolute;
    top: 36px;
    left: 6px;
}
}

    @media only screen and (min-width: 1200px) and (max-width: 1366px) {
     .view_all_multiple{
       width:27%!important;
       text-align: center;
     }
      .view_all_personalised{
       width:27%!important;
        text-align: center;
      }
      .view_all_trending_button{
                  width:27%!important;
                  text-align: center;
                }
   .hourDesign {
       top: -78px;
       left: 96px;
       font-size: 11px;
   }
   .minutesDesign {
       top: -77px;
       font-size: 11px;
       left: 159px;
   }
   .secondsDesign {
       TOP: -77PX;
       FONT-SIZE: 11PX;
       font-weight: 600;
       left: 225px;
   }


@media screen and (min-width: 1200px) and (max-width: 1366px) {
.recently-view-slider .slick-next {
    background: rgba(219, 219, 219, 0.5) url('{{ asset('assets/website/groot/2023/12/18/desktop/arrow-right.png') }}');
    no-repeat 11px 11px;
    right: 2px;
    background-size: 84px !important;
    background-position: -13px;
    left: 92% !important;
    position: absolute;
}

.recently-view-slider .slick-prev, .slick-next {
    font-size: 0;
    line-height: 0;
    position: absolute;
    top: 50%;
    display: block;
    left: 92.4% !important;
    border-radius: 50%;
    width: 58px;
    height: 60px;
    padding: 0;
    -webkit-transform: translate(0, -50%);
    -ms-transform: translate(0, -50%);
    transform: translate(0, -50%);
    cursor: pointer;
    color: transparent;
    border: 1px solid #efefef;
    outline: none;
    z-index: 9;
}

.slick-next.slick-arrow {
    position: absolute !important;
    left: 92.4% !important;
}
}

                   .priceOffDesignForDesktop{
                  border-radius: 4px!important;
                  padding-left: 6px!important;
                  padding-right: 6px!important;
                  padding-top: 4px!important;
                  padding-bottom: 4px!important;
                  }


              }


     @media screen and (min-width: 1367px) and (max-width: 1500px){

         .priceOffDesignForDesktop{
                            border-radius: 4px!important;
                            padding-left: 6px!important;
                            padding-right: 6px!important;
                            padding-top: 4px!important;
                            padding-bottom: 4px!important;
                            }

      .recently-view-slider .slick-next {background: rgba(219, 219, 219, 0.5) url("{{asset('assets/website/groot/2023/12/18/desktop/arrow-right.png')}}") no-repeat 11px 11px; right : 2px;background-size: 84px!important;background-position: -13px;left: 92%!important;position:absolute; }
      .recently-view-slider .slick-prev, .slick-next { font-size: 0;line-height: 0;position: absolute;top: 50%; display: block;left:92.4%!important; border-radius: 50%;width: 58px;height: 60px; padding: 0;-webkit-transform: translate(0, -50%); -ms-transform: translate(0, -50%); transform: translate(0, -50%); cursor: pointer; color: transparent; border: 1px solid #efefef; outline: none; z-index: 9;}
          .slick-next slick-arrow{
          left:92.4%!important;
           position:absolute!important;

                           }

          .hourDesign {
                        position: absolute!important;
                        top: -74px!important;
                        left: 106px!important;
                        font-size: 11px!important;
              }
              .minutesDesign {
                       position: absolute!important;
                       top: -74px!important;
                       font-size: 11px!important;
                       left: 170px!important;
              }
              .secondsDesign {
                  POSITION: ABSOLUTE!important;
                      TOP: -74PX!important;
                      FONT-SIZE: 11PX!important;
                      font-weight: 600!important;
                      left: 236px!important;

              }
      }
      .priceOffDesignForDesktop{
      color: #359B44;font-weight: 700;font-size:12px;background: #E5F7EE 0% 0% no-repeat padding-box;border-radius: 4px; padding-left: 8px;padding-right: 10px;padding-top: 4px;padding-bottom: 4px;margin-left: 10px;
       }

      .bestsellerFont{
       font-weight: 900!important;
      }



    </style>

    <div class="adbHomePage container" style="max-width: 1920px!important;width: 100%!important;margin-top: 33px;">
        <div class="swiper-container desk_banners adobeHeroBanner" style="margin:0 auto;padding:0 0 0;text-align: center;position:relative; overflow: hidden;">
            <div class="swiper-wrapper">

                @foreach ($banners as $banner)
                    <div class="swiper-slide">
                        <a class="center-align" href="best-selling-plants86b7.html?showMain=true">
                            <img alt="dynamic" style="width:100%" loading="lazy"
                                src="{{ asset($banner->image) }}"
                                title="Plant Delivery In India">
                        </a>
                    </div>
                @endforeach

                       
            </div>
            <div class="swiper-pagination"></div>
            <div class="swiper-button-prev"></div>
            <div class="swiper-button-next"></div>
        </div>
        </div>
        <div style="margin-top:-7px;" class=" max-container observerForCategory">
            <div class="row catEventHome" style="padding: 45px 33px 40px;margin:0 auto;">
     <div class="adobeEventPos col s2 padding-f1">
                      <div style="aspect-ratio:1">
                          <a class="center-align" href="gifts/mothers-day.html">
                              <img alt="cake delivery" loading="lazy" widgetType="featured category"
                                   class="responsive-img imageRadius"
                                   src="{{asset('assets/website/groot/2025/04/07/web/homepage-icon-desktop.jpg')}}"
                                   style="width:100%; height:100%">
                          </a>
                      </div>
                      <div class="wrapped-f1">Mother's Day</div>
                  </div>
              <div class=" adobeEventPos col s2 padding-f1">
                    <div style="aspect-ratio:1">
                        <a class="center-align" href="cake.html">
                            <img  alt="cake delivery" loading ="lazy"  widgetType="featured category" class=" responsive-img imageRadius" src="{{asset('assets/website/groot/2023/12/18/desktop/cake.jpg')}}" style="  width:100%; height:100%">
                        </a>
                    </div>
                    <div class="wrapped-f1">Cakes</div>
                </div>
                <div class=" adobeEventPos col s2 padding-f1">
                    <div style="aspect-ratio:1">
                        <a class="center-align" href="flowers.html">
                            <img  alt="flower delivery" loading ="lazy"   widgetType="featured category"  class=" responsive-img imageRadius" src="{{asset('assets/website/groot/2023/12/18/desktop/flowers.jpg')}}" style=" width:100%; height:100%">
                        </a>
                    </div>
                    <div class="wrapped-f1"> Flowers</div>
                </div>
                <div class="adobeEventPos col s2 padding-f1" >
                    <div style="aspect-ratio:1">
                        <a class="center-align" href="combos.html">
                            <img class=" responsive-img imageRadius" loading ="lazy" alt="cake and flowers combos" widgetType="featured category"  src="{{asset('assets/website/groot/2023/12/18/desktop/combos.jpg')}}" style=" width:100%; height:100%">
                        </a>
                    </div>
                    <div class="wrapped-f1">Combos</div>
                </div>
                 <div class="adobeEventPos col s2 padding-f1">
                    <div style="aspect-ratio:1">
                        <a class="center-align" href="plants.html">
                            <img class=" responsive-img imageRadius" loading ="lazy" alt="plants"  widgetType="featured category" src="{{asset('assets/website/groot/2023/12/18/desktop/plants.jpg')}}" style=" width:100%; height:100%">
                        </a>
                    </div>
                    <div class="wrapped-f1">Plants</div>
                </div>
                <div class=" adobeEventPos col s2 padding-f1" >
                    <div style="aspect-ratio:1">
                        <a class="center-align" href="chocolates.html">
                            <img class=" responsive-img imageRadius" loading ="lazy"   widgetType="featured category" alt="chocolate gifts"  src="{{asset('assets/website/groot/2023/12/18/desktop/chocolates.jpg')}}" style=" width:100%; height:100%">
                        </a>
                    </div>
                    <div class="wrapped-f1">Chocolates</div>
                </div>
                <div class=" adobeEventPos col s2 padding-f1" >
                    <div style="aspect-ratio:1">
                        <a class="center-align" href="gifts.html">
                            <img class=" responsive-img imageRadius" alt=" gifts" loading ="lazy"  widgetType="featured category" src="{{asset('assets/website/groot/2023/12/18/desktop/gifts.jpg')}}" style=" width:100%; height:100%">
                        </a>
                    </div>
                    <div class="wrapped-f1"> Gifts</div>
                </div>
                <div class=" adobeEventPos col s2 padding-f1">
                    <div style="aspect-ratio:1">
                        <a class="center-align" href="personalised-gifts.html">
                            <img alt="personalised gifts"  widgetType="featured category" loading ="lazy"  class=" responsive-img imageRadius" src="{{asset('assets/website/groot/2023/12/18/desktop/personalised.jpg')}}" style=" width:100%; height:100%">
                        </a>
                    </div>
                    <div class="wrapped-f1">Personalised</div>
                </div>
</div>
            <div class="row">
             <div class="col m12 s12 l12 center-align" style="color: #333333;font-size: 37px;font-weight: 700;margin-top:15px;"> Must Have</div>
            </div>
<div class="containerOne">
    <div class="leftOne">
        <!-- Left Side Images -->
          <a class="center-align" href="cake/kids-cakes86b7.html?showMain=true">
            <img class="paddingTopImage lazyload responsive-img" loading ="lazy" src="{{asset('assets/website/groot/2024/04/16/desktop/six-hundred-into-four-hundred-eighty.gif')}}" data-src="https://externalassets/groot/2024/06/29/desktop/kid-cake.png"  alt="Left1">
          </a>
       <a class="center-align" href="best-selling-plants.html">
        <img class="paddingTopImage lazyload responsive-img" loading ="lazy" src="{{asset('assets/website/groot/2024/06/29/desktop/plant.jpg')}}"  alt="Left2">
        </a>
         <a class="center-align" href="chocolate-bouquet.html">
        <img class="paddingTopImage lazyload responsive-img" loading ="lazy" style="padding:0px 10px 0px!important" src="{{asset('assets/website/groot/2024/04/16/desktop/six-hundred-into-four-hundred-eighty.gif')}}" data-src="https://externalassets/groot/2024/06/29/desktop/chocolate.jpg"   alt="Left3">
    </a>
    </div>
    <div class="centerOne">
        <!-- Center Images -->
        <a class="center-align" href="deals.html">
        <img class="paddingTopImage lazyload responsive-img" loading ="lazy" src="{{asset('assets/website/groot/2024/04/16/desktop/six-hundred-into-seven-hundred-fifty-four.gif')}}" data-src="https://externalassets/groot/2025/02/24/desktop/deal-desktop.jpg"   alt="Center1">
          </a>
        <a class="center-align" href="personalised-gifts/water-bottles.html">
        <img class="paddingTopImage lazyload responsive-img" loading ="lazy" src="{{asset('assets/website/groot/2024/04/16/desktop/six-hundred-into-eight-hundred-fifteen.gif')}}" data-src="https://externalassets/groot/2024/06/29/desktop/bottle.jpg"  alt="Center2">
      </a>
    </div>
    <div class="rightOne">
        <!-- Right Side Images -->
         <a class="center-align" href="roses.html">
        <img class="paddingTopImage lazyload responsive-img" loading ="lazy" src="{{asset('assets/website/groot/2024/04/16/desktop/five-hundred-eighty-eight-into-five-hundred.gif')}}" data-src="https://externalassets/groot/2024/06/29/desktop/rose.jpg"  alt="Right1">
          </a>
          <a class="center-align" href="personalised-gifts/photo-frames.html">
        <img class="paddingTopImage lazyload responsive-img" loading ="lazy" src="{{asset('assets/website/groot/2024/04/16/desktop/six-hundred-into-four-hundred-eighty.gif')}}" data-src="https://externalassets/groot/2024/06/29/desktop/frame.jpg"  alt="Right2">
         </a>
         <a class="center-align" href="personalised-gifts/accessories.html">
        <img class="paddingTopImage lazyload responsive-img" loading ="lazy" src="{{asset('assets/website/groot/2024/04/16/desktop/five-hundred-eighty-eight-into-five-hundred.gif')}}" data-src="https://externalassets/groot/2024/06/29/desktop/accessories-d.jpg')}}"  alt="Right3">
       </a>
    </div>
</div>
<div style="margin-top:-7px;" class=" max-container observerForCategory">
   <div class="swiper-container desk_banners-new  adobeOfferSlider" style="margin:0 auto;padding:0 0 0;text-align: center;position:relative; overflow: hidden;">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide adobeOfferStrip">
                                        <a class="center-align" href="offers/paytm.html">
                                            <img loading ="lazy" alt="dynamic"  style="width:95%;margin-top: 39px;margin-bottom: 29px;border-radius: 70px;" src="{{asset('assets/website/sf-img/live/visuals/home/desktop/2025/2/1740748602607.jpg')}}" title="Paytm Offer">
                                        </a>
                                    </div>
                                <div class="swiper-slide adobeOfferStrip">
                                        <a class="center-align" href="offers/mobikwikupi.html">
                                            <img loading ="lazy" alt="dynamic"  style="width:95%;margin-top: 39px;margin-bottom: 29px;border-radius: 70px;" src="{{asset('assets/website/sf-img/live/visuals/home/desktop/2025/2/1739355061157.jpg')}}" title="Mobikwik Upi Offer">
                                        </a>
                                    </div>
                                </div>
                </div>
             <div class="row catEventHomeWithTitle" style=" margin: 0 auto ;padding-top:0px!important;margin-top: 8px;margin-top: -10px;">
                                <div class="col l12 s12 m12" style="padding:0;margin-bottom:6px;margin:0 auto;">
                                    <div class="desktop-left-title" style="text-align: center;font-size: 34px!important;margin-top: 40px;">
                                         Cakes
                                    </div>
                                    </div>
                                    </div>
            <div class="row rowapd catEventHomeWithTitle" style=" margin: 0 auto ;padding-top:0px!important;padding-left: 26px;margin-bottom: 19px;padding-right: 26px;">
                <div class="col l12 s12 m12" style="padding:0;margin:0 auto;margin-top: -10px;margin-bottom: 5px;">
                     <div class=" col l4 s4 desktop-left-title">
                    </div>
                    <div class=" col l4 s4 desktop-left-title">
                        <div class="color: #333333;" style="text-align: center;font-size: 27px;font-weight: 500;">Dreamy cakes for every occasion</div>
                    </div>
                    <a  style="color:white" href="cake.html">
                        <div class="col l4 s4 view_all" style="background: #E2E2E2 0% 0% no-repeat padding-box;border: 1px solid #E6E6E6;border-radius: 4px;color: #22181C;font-weight:600;padding: 7px!important;">
                            VIEW ALL
                        </div>
                    </a>
                </div>
                <div class="adobeEventPos col s3 l3 m3 padding-vl">
                    <a class="center-align" href="cake/photo-cake.html">
                        <div class="card "  style='border-radius:14px;box-shadow:none;overflow:hidden;margin:0;background-color: #FFFFFF!important;'>
                            <div class="card-image">
                                <img loading ="lazy" alt="Birthday Cakes" widgetType="cake category" class=" lazyload responsive-img " src="{{asset('assets/website/groot/2024/04/16/desktop/four-hundred-thirty-four-into-four-hundred.gif')}}" data-src="https://externalassets//groot/2024/01/22/desktop/photo-cake.jpg" style="width:100%;height:100%">
                                <div class="card-content col l12 s12 m12" style='padding: 17px 0px 13px;padding-top: 0px;'>
                                    <div class="truncate" style='padding-right: 0;text-align: center;color: #404040;border: 1px solid;padding-top: 12px;padding-bottom: 10px;background: #FFFFFF 0% 0% no-repeat padding-box;border: 1px solid #e8e8e8;border-radius: 0px 0px 15px 15px;border-top: 0px;'>
                                        <span style="font-size: 15px;display:block;font-weight:800;text-align: center;">Photo Cakes</span>
                                        <span style='font-size:15px;'>Starting From</span>
                                        <span style='font-size:15px;' class="moneySymbol">₹ </span>
                                        <span style='font-size:15px;'  class="moneyCal" data-inr="899">899</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="adobeEventPos col s3 l3 m3 padding-vl">
                    <a class="center-align" href="cake/pinata-cake.html">
                        <div class="card " style='border-radius:14px;box-shadow:none;overflow:hidden;margin:0;background-color: #FFFFFF!important;'>
                            <div class="card-image">
                                <img loading ="lazy" alt="Anniversary Cakes" widgetType="cake category"  class=" lazyload responsive-img " src="{{asset('assets/website/groot/2024/04/16/desktop/four-hundred-thirty-four-into-four-hundred.gif')}}" data-src="https://externalassets/groot/2024/01/22/desktop/pinata-cake.jpg" style="width:100%;height:100%">
                                <div class="card-content" style='padding: 17px 0px 13px;padding-top: 0px;'>
                                    <div class="truncate" style='padding-right: 0;text-align: center;color: #404040;border: 1px solid;padding-top: 12px;padding-bottom: 10px;background: #FFFFFF 0% 0% no-repeat padding-box;border: 1px solid #e8e8e8;border-radius: 0px 0px 15px 15px;border-top: 0px;'>
                                        <span style="font-size: 15px;display:block;font-weight:800;text-align: center;">Pinata Cakes</span>
                                        <span style='font-size:15px;'>Starting From</span>
                                        <span style='font-size:15px;' class="moneySymbol">₹ </span>
                                        <span style='font-size:15px;'  class="moneyCal" data-inr="1,399">1,399</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="adobeEventPos col s3 l3 m3 padding-vl">
                    <a class="center-align" href="cake/pull-me-up-cake.html">
                        <div class="card " style='border-radius:14px;box-shadow:none;overflow:hidden;margin:0;background-color:#FFFFFF!important;'>
                            <div class="card-image">
                                <img loading ="lazy" alt="Kids Cakes" widgetType="cake category" class=" lazyload responsive-img " src="{{asset('assets/website/groot/2024/04/16/desktop/four-hundred-thirty-four-into-four-hundred.gif')}}" data-src="https://externalassets/groot/2024/10/16/yummilicious-ferreo-truffle-cake.jpg" style="width:100%;height:100%">
                                <div class="card-content col l12 s12 m12" style='padding: 17px 0px 13px;padding-top: 0px;'>
                                    <div class=" truncate" style='padding-right: 0;text-align: center;color: #404040;border: 1px solid;padding-top: 12px;padding-bottom: 10px;background: #FFFFFF 0% 0% no-repeat padding-box;border: 1px solid #e8e8e8;border-radius: 0px 0px 15px 15px;border-top: 0px;'>
                                        <span style="font-size: 15px;display:block;font-weight:800;text-align: center;">Pull Me Up Cake</span>
                                        <span style='font-size:15px;'>Starting From</span>
                                        <span style='font-size:15px;' class="moneySymbol">₹ </span>
                                        <span style='font-size:15px;'  class="moneyCal" data-inr="1,549">1,549</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="adobeEventPos col s3 l3 m3 padding-vl">
                    <a class="center-align" href="cake/kids-cakes.html">
                        <div class="card " style='border-radius:14px;box-shadow:none;overflow:hidden;margin:0;background-color:#FFFFFF!important;'>
                            <div class="card-image">
                                <img loading ="lazy" alt="Premium Cakes" widgetType="cake category" class=" lazyload responsive-img " src="{{asset('assets/website/groot/2024/04/16/desktop/four-hundred-thirty-four-into-four-hundred.gif')}}" data-src="https://externalassets/groot/2024/01/22/desktop/kids-cake-desktop.jpg" style="width:100%;height:100%">
                                <div class="card-content" style='padding: 17px 0px 13px;padding-top: 0px;'>
                                    <div class=" truncate" style='padding-right: 0;text-align: center;color: #404040;border: 1px solid;padding-top: 12px;padding-bottom: 10px;background: #FFFFFF 0% 0% no-repeat padding-box;border: 1px solid #e8e8e8;border-radius: 0px 0px 15px 15px;border-top: 0px;'>
                                        <span style="font-size: 15px;display:block;font-weight:800;text-align: center;">Kids Cakes </span>
                                        <span style='font-size:15px;'>Starting From</span>
                                        <span style='font-size:15px;' class="moneySymbol">₹ </span>
                                        <span style='font-size:15px;'  class="moneyCal" data-inr="749">749</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
<div loading ="lazy" id="bestSeller-div" style="background: #FFF7FA 0% 0% no-repeat padding-box;border-radius: 20px;padding-top: 51px;padding-bottom: 12px;margin-left: 32px;margin-right: 33px;padding-bottom: 2.3%;">
<div class="row" style="padding-left: 77px;">
<div style="position:relative;margin-top: -4px;"><span class="bottomLineDesign" style="font-size: 14px;"></span></div>
<div class="col m2 l2 bestsellerFont" style="font-size: 37px;font-weight: 900!important;">Bestsellers</div>
<div class="col">  <div id="cakeTab" class="tabOne active" onclick="openTab(event, 'tab1')" onKeyPress="handleKeyPress(event)" onKeyDown="handleKeyDown(event)" onKeyUp="handleKeyUp(event)" style="width:100%;padding: 6px 30px 6px;font-size: 25px;border-radius:5px 5px 0px 0px;position:relative;font-weight:900;">Cakes
<img loading ="lazy" id="arrowImageFirst" src="{{asset('assets/website/groot/2023/12/18/desktop/downword-errow.png')}}" alt="Arrow" style="position: absolute; bottom: -10px; left: 50%; transform: translateX(-50%);">
</div></div>
<div class="col"> <div id="FlowerTab" class="tabOne" onclick="openTab(event, 'tab2')" onkeypress="handleKeyPress(event)" onkeydown="handleKeyDown(event)" onkeyup="handleKeyUp(event)" style="width:100%;padding: 6px 30px 6px;font-size: 25px;border-radius:5px 5px 0px 0px;position:relative;font-weight:900;">Flowers
  <img loading ="lazy" id="arrowImageSecond" src="{{asset('assets/website/groot/2023/12/18/desktop/downword-errow.png')}}" alt="Arrow" style="position: absolute; bottom: -10px; left: 50%; transform: translateX(-50%);display:none;">
</div></div>

<div> <div class="cakeViewAllButton"  style="width:100%;padding: 10px 45px 10px;font-size: 25px;text-align:right;padding-right: 6%;position:relative;">  <a class="center-align" href="cake.html"><span style=" background: #FFB3CE 0% 0% no-repeat padding-box;border: 1px solid #E6E6E6;border-radius: 5px;padding: 8px 16px;font-size: 16px;font-weight: 600;position: absolute;right: 92px;top: 1px;color: #22181C;">VIEW ALL</span> </a></div></div>

 <div> <div class="flowerViewAllButton"  style="width:100%;padding: 10px 45px 10px;font-size: 25px;text-align:right;padding-right: 6%;display:none;position:relative;">  <a class="center-align" href="flowers.html"><span style="background: #FFB3CE 0% 0% no-repeat padding-box;border: 1px solid #E6E6E6;border-radius: 5px;padding: 8px 16px;font-size: 16px;font-weight: 600;position: absolute;right: 92px;top: 1px;color: #22181C;">VIEW ALL</span> </a></div></div>
</div>

<div id="tab1" class="content active tabWidth" style="width: 89%!important;margin: 0 auto!important;">

   <div class="cakeBestsellers">
    <div class="col m12 s12 l12" style="text-align: center;">
                 <img  alt="gif"  class="preloderForImage" src="{{asset('assets/website/groot/2022/12/26/desktop/processing-gif-second.gif')}}">
             </div>
   </div>
</div>
<div id="tab2" class="content tabWidth" style="width: 89%!important;margin: 0 auto!important;">
   <div class="flowersBestsellers" id="flowersBestsellers">
   <div class="col m12 s12 l12" style="text-align: center;">
                        <img  alt="gif" class="preloderForImage" src="{{asset('assets/website/groot/2022/12/26/desktop/processing-gif-second.gif')}}">
                    </div>
   </div>
        </div>
</div>


                              <div id="expressCountDown" loading ="lazy" class=" center-align container hide" style="display:none;background-image: url('{{asset('assets/website/groot/2023/12/18/desktop/countdown-timer-backgroud-image.jpg')}}'); background-repeat: no-repeat;background-size: 100% 100%; text-align: center; margin:0 31px;border-radius:14px;margin-top: 48px;margin-bottom: 27px;margin:0 auto;max-width: 1540px;margin-top: 66px;margin-bottom: 17px;">
                                <div class="row" style="margin: 0px 60px 0px;padding-top: 11px;">
                                <div class="col m3" style="margin-left: 1.6%;">
                                    <div class="timerDesignForDesktop" style="line-height: 49px;font-family: Open Sans, sans-serif;font-weight: lighter;margin-top: 31px;font-size: 43px;color: #fafafa;letter-spacing: 3px;margin-bottom: 26px;display: flex;margin-bottom: 10px!important;">
                                    <div>
                                    <span id="addHours" style="background:#3f3f3f;padding: 10px;border-radius: 10px;margin-top: 49px!important;"></span>
                                    <div style="color:#333;font-size: 10px;font-weight: 700;text-align: center;margin-top: -4px;">HOURS</div>
                                   </div>
                                    <div style="width: 36%;">
                                    <span id="addMinutes" style="background:#3f3f3f;padding: 10px;border-radius: 10px;"></span>
                                     <div  style="color: #333;font-size: 10px;font-weight: 700;text-align: center!important;margin-top: -4px;">MINUTES</div>
                                     </div>
                                    <div>
                                    <span id="addSeconds" style="background:#3f3f3f;padding: 10px;border-radius: 10px;"></span>
                                    <div  style="color: #333;font-size: 10px;font-weight: 700;text-align: center;margin-top: -4px;">SECONDS</div>
                                       </div>
                                    </div>
                                </div>
                                    <div class="col m6" style="position: relative;">
                                            <div style="margin:0;font-size:20px;font-weight:600;text-align:left;">
                                                <span class="hourLeftToday">Hours left for today's delivery</span>
                                            </div>
                                      </div>
                                      <div class="col s3 m3" style=" margin-top: 32px; float: right;">
                                          <a href ="express-delivery.html" >
                                            <img src="{{asset('assets/website/groot/2024/01/31/explore-now-btn-desktop.png')}}" style="width: 83%;" alt="explore-now-btn-desktop" />
                                          </a>
                                      </div>
                                </div>

                              </div>



             <div class="row catEventHomeWithTitle max-container" style=" margin: 0 auto ;padding-top:0px!important;">
                <div class="col l12 s12 m12" style="padding:0;margin-bottom:6px;margin:0 auto;margin-top:58px;">
                    <div class="desktop-left-title" style="text-align: center;font-size: 34px!important;margin-top: 35px;margin-top: 0px;">
                         Flowers
                    </div>
                    </div>
                    </div>
            <div class="row rowapd catEventHomeWithTitle max-container" style=" margin: 0 auto ;padding-top: 0px;padding-bottom: 36px;">

                 <div class="col l12 s12 m12" style="padding:0;margin:0 auto;margin-top: -10px;margin-bottom: 20px;margin-bottom: 15px;">
                     <div class=" col l4 s4 desktop-left-title">
                    </div>
                    <div class=" col l4 s4 desktop-left-title">
                        <div class="color: #333333;" style="text-align: center;font-size: 27px;font-weight: 500;">Petals of Happiness</div>
                    </div>
                    <a  style="color:white" href="flowers.html">
                        <div class="col l4 s4 view_all" style="background: #E2E2E2 0% 0% no-repeat padding-box;border: 1px solid #E6E6E6;border-radius: 4px;color: #22181C;font-weight:600;padding: 7px!important;">
                            VIEW ALL
                        </div>
                    </a>
                </div>
                <div class="adobeEventPos col s3 l3 m3 padding-vl ">
                    <a class="center-align" href="roses.html">
                        <div class="card " style='border-radius:14px;box-shadow:none;overflow:hidden;margin:0;background-color: #FFFFFF!important;'>
                            <div class="card-image">
                                <img alt="Birthday Flowers" loading ="lazy" widgetType="flower category" class=" lazyload responsive-img " src="{{asset('assets/website/groot/2023/03/09/desktop/spinner-two.gif')}}" data-src="https://externalassets/groot/2023/12/18/desktop/flowers-first-image.jpg?w=385" style="width:100%;height:100%">
                                <div class="card-content col l12 s12 m12" style='padding: 17px 0px 13px;padding-top:0px;'>
                                    <div class=" col l12 s12 m12 truncate" style='padding-right: 0;text-align:center;color:#404040;line-height:19px;background: #FFFFFF 0% 0% no-repeat padding-box;border: 1px solid #e8e8e8;border-radius: 0px 0px 15px 15px;border-top: 0px;padding-bottom: 12px;'>
                                        <span style="font-size: 18px;display:block;font-weight:800;text-align: center;padding-top: 12px;padding-bottom: 7px;">Roses  </span>
                                        <span style='font-size:15px;'>Starting From</span>
                                        <span style='font-size:15px;' class="moneySymbol">₹ </span>
                                        <span style='font-size:15px;'  class="moneyCal" data-inr="499">499</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="adobeEventPos col s3 l3 m3 padding-vl">
                    <a class="center-align" href="flowers/basket.html">
                        <div class="card " style='border-radius:14px;box-shadow:none;overflow:hidden;margin:0;background-color: #FFFFFF!important;'>
                            <div class="card-image">
                                <img loading ="lazy" alt="Anniversary Flowers" widgetType="flower category"  class=" lazyload responsive-img "  src="{{asset('assets/website/groot/2023/03/09/desktop/spinner-two.gif')}}" data-src="https://externalassets/groot/2023/12/18/desktop/basket-arrangement.jpg?w=385" style="width:100%;height:100%">
                                <div class="card-content col l12 s12 m12" style='padding: 17px 0px 13px;padding-top:0px;'>
                                    <div class="  col l12 s12 m12 truncate" style='padding-right: 0;text-align:center;color:#404040;line-height:19px;background: #FFFFFF 0% 0% no-repeat padding-box;border: 1px solid #e8e8e8;border-radius: 0px 0px 15px 15px;border-top: 0px;padding-bottom: 12px;'>
                                        <span style="font-size: 18px;display:block;font-weight:800;text-align: center;padding-top: 12px;padding-bottom: 7px;">Basket Arrangements </span>
                                        <span style='font-size: 15px;'>Starting From</span>
                                        <span style='font-size: 15px;' class="moneySymbol">₹ </span>
                                        <span style='font-size: 15px;'  class="moneyCal" data-inr="1,049">1,049</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="adobeEventPos col s3 l3 m3 padding-vl">
                    <a class="center-align" href="flowers/premium.html">
                        <div class="card " style='border-radius:14px;box-shadow:none;overflow:hidden;margin:0;background-color:#FFFFFF!important;'>
                            <div class="card-image">
                                <img alt="Congratulations Flowers" loading ="lazy" widgetType="flower category" class=" lazyload responsive-img "  src="{{asset('assets/website/groot/2023/03/09/desktop/spinner-two.gif')}}" data-src="https://externalassets/groot/2023/12/18/desktop/premium-flowers.jpg?w=385" style="width:100%;height:100%">
                                <div class="card-content col l12 s12 m12" style='padding: 17px 0px 13px;padding-top:0px;'>
                                    <div class="  col l12 s12 m12 truncate" style='padding-right: 0;text-align:center;color:#404040;line-height:19px;background: #FFFFFF 0% 0% no-repeat padding-box;border: 1px solid #e8e8e8;border-radius: 0px 0px 15px 15px;border-top: 0px;padding-bottom: 12px;'>
                                        <span style="font-size:18px;display:block;font-weight:800;padding-top: 12px;padding-bottom: 7px;">Premium Flowers</span>
                                        <span style='font-size:15px;'>Starting From</span>
                                        <span style='font-size:15px;' class="moneySymbol">₹ </span>
                                        <span style='font-size:15px;'  class="moneyCal" data-inr="849">849</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="adobeEventPos col s3 l3 m3 padding-vl">
                    <a class="center-align" href="flowers/lilies.html">
                        <div class="card " style='border-radius:14px;box-shadow:none;overflow:hidden;margin:0;background-color:#FFFFFF!important;'>
                            <div class="card-image">
                                <img alt="Roses" loading ="lazy" widgetType="flower category"  class=" lazyload responsive-img "  src="{{asset('assets/website/groot/2023/03/09/desktop/spinner-two.gif')}}" data-src="https://externalassets/groot/2023/12/18/desktop/lillies.jpg?w=385" style="width:100%;height:100%">
                                <div class="card-content col l12 s12 m12" style='padding: 17px 0px 13px;padding-top:0px;'>
                                    <div class="col l12 s12 m12 truncate" style='padding-right: 0;text-align:center;color:#404040;line-height:19px;background: #FFFFFF 0% 0% no-repeat padding-box;border: 1px solid #e8e8e8;border-radius: 0px 0px 15px 15px;border-top: 0px;padding-bottom: 12px;'>
                                        <span style="font-size:18px;display:block;font-weight:800;padding-top: 12px;padding-bottom: 7px;">Lilies   </span>
                                        <span style='font-size:15px;'>Starting From</span>
                                        <span style='font-size:15px;' class="moneySymbol">₹ </span>
                                        <span style='font-size:15px;'  class="moneyCal" data-inr="1,049">1,049</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>


<div loading ="lazy"  id="trending-gifts" style="background: #FFFAEB 0% 0% no-repeat padding-box;border-radius: 20px;padding-bottom: 12px;margin-left: 32px;margin-right: 33px;padding-bottom: 2.3%;">
<div class="row" style="padding-left: 77px;">
</div>

<div style="background: #FFFAEB 0% 0% no-repeat padding-box;border-radius: 20px;margin-left: 26px;margin-right: 26px;margin:0 auto;max-width: 1540px;padding-bottom: 0.5%;" class="container">
            <div class="row rowapd catEventHomeWithTitle" style="margin: 0 auto;margin-left: 39px;margin-right: 27px;padding-bottom: 0px;padding-top: 29px;">
                <div class=" col l12 s12 m12" style="padding:0;margin-bottom:10px;">
                    <div class="desktop-left-title col l8 m8" style="padding-left: 0px;font-size: 31px!important;">
                        Trending Gifts
                    </div>
                    <a  style="color:white" href="gifts/trending.html">
                        <div class="col l4 s4" style="justify-content: end;display: flex;">
                           <span class="view_all_trending_button" style="pointer-events: all;"> VIEW ALL </span>
                        </div>
                    </a>
                </div>

            </div>

        </div>
<div id="Tab6" class="content active " style="padding-bottom: 12px;width: 91%;margin: 0 auto!important;">
                                <div class="trendingGifts">
                                   <div class="col m12 s12 l12" style="text-align: center;">
                                                        <img  class="preloderForImage" src="{{asset('assets/website/groot/2022/12/26/desktop/processing-gif-second.gif')}}" alt="processing-gif-second"/>
                                                    </div>
                                </div>
                            </div>

</div>



        <div style="background: #F5FAFF 0% 0% no-repeat padding-box;border-radius: 20px;margin-left: 26px;margin-right: 26px;margin-top: 45px;margin-bottom: 25px;margin:0 auto;max-width: 1540px;padding-bottom: 2.2%;" class="container">

                           <div class="row rowapd catEventHome" style="margin:10px auto 0;margin-top: 60px;">
                           <div class="col l12 s12 m12" style="padding: 0 47px 0;margin-bottom:6px; margin: 12px 0px 0px;">
                                                                   <div class="col l8 s8 desktop-left-title" style="line-height: 13px;font-size: 31px!important;">
                                                                       Personalized Gifts
                                                                       <div style="color: #333333;font-size:14px;font-weight:600;padding-top: 15px;"> Customized with Love and Care</div>
                                                                   </div>
                                                                   <a style="color:white" href="personalised-gifts.html">
                                                                   <div class="col l4 s4" style="justify-content: end;display: flex;padding-left: 0px;">
                                                                    <span class="col l4 s4 view_all_personalised">VIEW ALL</span>
                                                                   </div>
                                                                   </a>
                                                               </div>
                               <div class="adobeEventPos col s12 l12 m12 padding-vl" style="padding-left: 54px!important;padding-right: 54px!important;margin-top: 30px;">
                                   <a href="personalised-gifts86b7.html?showMain=true">
                                       <img alt="gift for him" loading ="lazy" bannerType="relation category"  class="lazyload responsive-img "  src="{{asset('assets/website/groot/2023/03/09/desktop/spinner-two.gif')}}" data-src="https://externalassets/groot/2024/01/18/desktop/personalised-gift-stripe-desktop.jpg')}}" style="border-radius:8px;width:100%;height:100%">
                                   </a>
                               </div>

                           </div>

            <div id="personalized-bestseller" class="row rowapd catEventHomeWithTitle" style="margin: 0 auto;margin-left: 64px;margin-right: 48px;padding-bottom: 48px;padding-top: 3px;">
                <div class=" col l12 s12 m12" style="padding:0;margin-bottom:10px;margin:0 auto">
                    <div  class="desktop-left-title col l8 m8" style="padding-left: 0px;font-size: 31px!important;">
                        Personalised Bestsellers
                    </div>
                    <a  style="color:white" href="personalised-gifts.html">
                        <div class="col l4 s4" style="justify-content: end;display: flex;padding-left: 0px;">
                        <span class="col l4 s4 view_all_personalised">VIEW ALL</span>
                        </div>
                    </a>
                </div>

            </div>
             <div id="Tab7" class="content active" style="padding-bottom: 12px;width: 91%;margin: 0 auto!important;margin-top: -29px!important;">
                                  <div class="personalisedBestsellers">
                                           <div class="col m12 s12 l12" style="text-align: center;">
                                                                <img  class="preloderForImage" src="{{asset('assets/website/groot/2022/12/26/desktop/processing-gif-second.gif')}}" alt="processing-gif-second" />
                                                            </div>
                                  </div>
                            </div>
                              </div>


            <div class="row rowapd catEventHome max-container" style="margin:10px auto 0;padding-top: 36px;padding-bottom: 51px;">
                <div class="adobeEventPos col s6 l6 m6 padding-vl">
                    <a href="gifts/for-him.html">
                        <img alt="gift for him" loading ="lazy" bannerType="relation category"  class="custom-shadow lazyload responsive-img "  src="{{asset('assets/website/groot/2024/04/16/desktop/spinner-seven-hunderd-seventy-five.gif')}}" data-src="https://externalassets/groot/2023/12/18/desktop/gifts-for-him.jpg?w=775" style="border-radius:8px;width:100%;height:100%">
                    </a>
                </div>
                <div class="adobeEventPos col s6 l6 m6 padding-vl">
                    <a href="gifts/for-her.html">
                        <img alt="gift for her" loading ="lazy" bannerType="relation category"  class="custom-shadow lazyload responsive-img " src="{{asset('assets/website/groot/2024/04/16/desktop/spinner-seven-hunderd-seventy-five.gif')}}" data-src="https://externalassets/groot/2023/12/18/desktop/gifts-for-her.jpg?w=775" style="border-radius:8px;width:100%;height:100%">
                    </a>
                </div>
            </div>
                            <div class="row center-align container" style='margin:0 auto!important;padding: 32px 47px 32px 71px;background: #FFFAEB 0% 0% no-repeat padding-box;border-radius: 20px;margin: 0px 22px;max-width: 1540px;padding-right: 0px;'>
                                <div class="col l12 m12 safe_portn" style="float: none; margin: 0 auto;">
                                    <div class=" col s3 m3 l3" style=" text-align:center;padding:0; display: flex; align-items: center;">
                                        <div class="img_left" >
                                            <img class=" lazyload responsive-img" loading ="lazy"  alt="processing-gif-second" src="{{asset('assets/website/groot/2024/04/16/desktop/one-hundred-fifteen-into-one-hundred-fifteen.gif')}}" data-src="https://externalassets/groot/2023/12/18/desktop/preferred-time-slot-selection.png?w=115" style="width:100%;height:100%">
                                        </div>
                                        <div class="content_right" style="text-align:left;font-weight:bold;line-height:118%;padding-left:15px;width:100%;">
                                            <div style="line-height:24px;color: #333333;font-size:20px;">Preferred Time<span style="color:#333333;font-size:18px;display: block;">Slot Selection</span></div>
                                        </div>
                                    </div>
                                    <div class=" col s3 m3 l3" style=" text-align:center;padding:0; display: flex; align-items: center;">
                                        <div class="img_left">
                                            <img class=" lazyload responsive-img" loading ="lazy" alt="processing-gif-second" src="{{asset('assets/website/groot/2024/04/16/desktop/one-hundred-fifteen-into-one-hundred-fifteen.gif')}}" data-src="https://externalassets/groot/2023/12/18/desktop/delivery-in-cities.png?w=115"  style="width:100%;height:100%">

                                        </div>
                                        <div class="left" style="text-align:left;font-weight:bold;line-height:118%;padding-left:15px;width:100%;">
                                            <div  style="line-height:24px;color: #333333;font-size:20px;">Delivery in 700+ <span style="color:#333333;font-size:18px;display: block;">Cities</span></div>

                                        </div>
                                    </div>
                                    <div class=" col s3 m3 l3" style=" text-align:center;padding:0; display: flex; align-items: center;">
                                        <div class="img_left" >
                                            <img class=" lazyload responsive-img " loading ="lazy" alt="processing-gif-second" src="{{asset('assets/website/groot/2024/04/16/desktop/one-hundred-fifteen-into-one-hundred-fifteen.gif')}}" data-src="https://externalassets/groot/2023/12/18/desktop/twenty-million-people-trust-us.png?w=115" style="width:100%;height:100%">
                                        </div>
                                        <div class="left" style="text-align:left;font-weight:bold;line-height:118%;padding-left:15px;width:100%;">
                                            <div style="line-height:24px;color: #333333;font-size:20px;">20 Million People <span style="color:#333333;font-size:18px;display: block;">Trust Us</span></div>
                                        </div>
                                    </div>

                                    <div class=" col s3 m3 l3" style=" text-align:center;padding:0; display: flex; align-items: center;">
                                        <div class="img_left">
                                            <img class=" lazyload responsive-img " loading ="lazy" alt="processing-gif-second" src="{{asset('assets/website/groot/2024/04/16/desktop/one-hundred-fifteen-into-one-hundred-fifteen.gif')}}" data-src="https://externalassets/groot/2023/12/18/desktop/pincodes-serviced-till-date.png?w=115" style="width:100%;height:100%">

                                        </div>
                                        <div class="left" style="text-align:left;font-weight:bold;line-height:118%;padding-left:15px;width:100%;">
                                            <div style="line-height:24px;color: #333333;font-size:20px;">18000+ Pincodes <span style="color:#333333;font-size:18px;display: block;">Serviced Till Date</span>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
               <div class="row catEventHomeWithTitle max-container" style=" margin: 0 auto!important;padding-top:0px!important;">
                   <div class="col l12 s12 m12" style="padding:0;margin-bottom:6px;margin:0 auto;">
                       <div class="desktop-left-title" style="margin-left: 5px;text-align: center;font-size: 34px!important;margin-top: 31px;margin-top: 60px;padding-bottom: 3px!important;">
                            Combos and Hampers
                       </div>
                       </div>
                       </div>
            <div class="row rowapd catEventHomeWithTitle max-container" style=" margin: 0 auto!important;padding-top: 0px;">
                 <div class="col l12 s12 m12" style="padding:0;margin:0 auto;margin-top: 0px;margin-bottom: 15px!important;">
                    <div class=" col l4 s4 desktop-left-title">
                   </div>
                   <div class=" col l4 s4 desktop-left-title">
                       <div class="color: #333333;" style="text-align: center;font-size: 27px;font-weight: 500;">Tailored For Every Occasion</div>
                   </div>
                   <a  style="color:white" href="combos.html">
                       <div class="col l4 s4 justifyEndClass" style="justify-content: end;display: flex;padding-left: 0px;margin-top: 10px;">
                          <span class="view_all_multiple"> VIEW ALL </span>
                       </div>
                   </a>
               </div>
                <div class="adobeEventPos col s3 l3 m3 padding-vl">
                    <a class="center-align" href="combos/flowers.html">
                        <div class="card " style='border-radius:14px;box-shadow:none;overflow:hidden;margin:0;background-color: #FFFFFF!important;'>
                            <div class="card-image">
                                <img  alt="Flowers and Teddy" loading ="lazy" widgetType="combos category" class=" lazyload responsive-img " src="{{asset('assets/website/groot/2024/04/16/desktop/three-hundred-eighty-five-into-three-hundred-fifty-five.gif')}}" data-src="https://externalassets/groot/2023/12/18/desktop/flower-and-combos.jpg?w=385" style="width:100%;height:100%">
                                <div class="card-content col l12 s12 m12" style='padding: 17px 0px 13px;padding-top:2px;'>
                                    <div class=" col l12 s12 m12 truncate" style='padding-right: 0;text-align:center;color:#404040;line-height:19px;background: #FFFFFF 0% 0% no-repeat padding-box;border: 1px solid #e8e8e8;border-radius: 0px 0px 15px 15px;border-top: 0px;padding-bottom: 13px;'>
                                        <span style="font-size:17px;display:block;font-weight:800;padding-top: 12px;
                                                                                                      padding-bottom: 7px;">Flower Combos </span>
                                        <span style='font-size:13px;'>Starting From</span>
                                        <span style='font-size:13px;' class="moneySymbol">₹ </span>
                                        <span style='font-size:13px;'  class="moneyCal" data-inr="679">679</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="adobeEventPos col s3 l3 m3 padding-vl">
                    <a class="center-align" href="combos/cake.html">
                        <div class="card " style='border-radius:14px;box-shadow:none;overflow:hidden;margin:0;background-color: #FFFFFF!important;'>
                            <div class="card-image">
                                <img alt="Flower Combos" widgetType="combos category"  class=" lazyload responsive-img " src="{{asset('assets/website/groot/2024/04/16/desktop/three-hundred-eighty-five-into-three-hundred-fifty-five.gif')}}" data-src="https://externalassets/groot/2023/12/18/desktop/cake-combos.jpg?w=385" style="width:100%;height:100%">
                                <div class="card-content col l12 s12 m12" style='padding: 17px 0px 13px;padding-top:2px;'>
                                    <div class=" col l12 s12 m12 truncate" style='padding-right: 0;text-align:center;color:#404040;line-height:19px;background: #FFFFFF 0% 0% no-repeat padding-box;
                                                                                                                                                        border: 1px solid #e8e8e8;
                                                                                                                                                        border-radius: 0px 0px 15px 15px;
                                                                                                                                                        border-top: 0px;    padding-bottom: 13px;'>
                                        <span style="font-size:17px;display:block;font-weight:800;padding-top: 12px;padding-bottom: 7px;">Cake Combos </span>
                                        <span style='font-size:13px;'>Starting From</span>
                                        <span style='font-size:13px;' class="moneySymbol">₹ </span>
                                        <span style='font-size:13px;'  class="moneyCal" data-inr="999">999</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="adobeEventPos col s3 l3 m3 padding-vl">
                    <a class="center-align" href="combos/flowers-and-chocolates.html">
                        <div class="card " style='border-radius:14px;box-shadow:none;overflow:hidden;margin:0;background-color:#FFFFFF!important;'>
                            <div class="card-image">
                                <img alt="Cake and Chocolates" loading ="lazy" widgetType="combos category"  class=" lazyload responsive-img "   src="{{asset('assets/website/groot/2024/04/16/desktop/three-hundred-eighty-five-into-three-hundred-fifty-five.gif')}}" data-src="https://externalassets/groot/2023/12/18/desktop/flowers-and-chocolates.jpg?w=385" style="width:100%;height:100%">
                                <div class="card-content col l12 s12 m12" style='padding: 17px 0px 13px;padding-top:2px;'>
                                    <div class=" col l12 s12 m12 truncate" style='padding-right: 0;text-align:center;color:#404040;line-height:19px;background: #FFFFFF 0% 0% no-repeat padding-box;
                                                                                                                                                        border: 1px solid #e8e8e8;
                                                                                                                                                        border-radius: 0px 0px 15px 15px;
                                                                                                                                                        border-top: 0px;    padding-bottom: 13px;'>
                                        <span style="font-size:17px;display:block;font-weight:800;padding-top: 12px;padding-bottom: 7px;">Flowers and Chocolates</span>
                                        <span style='font-size:13px;'>Starting From</span>
                                        <span style='font-size:13px;' class="moneySymbol">₹ </span>
                                        <span style='font-size:13px;'  class="moneyCal" data-inr="699">699</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="adobeEventPos col s3 l3 m3 padding-vl">
                    <a class="center-align" href="personalised-gifts/combo.html">
                        <div class="card " style='border-radius:14px;box-shadow:none;overflow:hidden;margin:0;background-color:#FFFFFF!important;'>
                            <div class="card-image">
                                <img alt="Cake Combos" loading ="lazy" widgetType="combos category"  class=" lazyload responsive-img " src="{{asset('assets/website/groot/2024/04/16/desktop/three-hundred-eighty-five-into-three-hundred-fifty-five.gif')}}" data-src="https://externalassets/groot/2023/12/18/desktop/personalised-combos.jpg?w=385" style="width:100%;height:100%">
                                <div class="card-content col l12 s12 m12" style='padding: 17px 0px 13px;padding-top:2px;'>
                                    <div class=" col l12 s12 m12 truncate" style='padding-right: 0;text-align:center;color:#404040;line-height:19px;background: #FFFFFF 0% 0% no-repeat padding-box;border: 1px solid #e8e8e8;border-radius: 0px 0px 15px 15px;border-top: 0px;    padding-bottom: 13px;'>
                                        <span style="font-size:17px;display:block;font-weight:800;padding-top: 12px;padding-bottom: 7px;">Personalised Combos </span>
                                        <span style='font-size:13px;'>Starting From</span>
                                        <span style='font-size:13px;' class="moneySymbol">₹ </span>
                                        <span style='font-size:13px;'  class="moneyCal" data-inr="499">499</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>

                             <div class="row catEventHomeWithTitle max-container" style=" margin: 0 auto!important;padding-top:0px!important;">
                                                   <div class="col l12 s12 m12" style="padding:0;margin-bottom:6px;margin:0 auto;">
                                                       <div class="desktop-left-title" style="text-align: center;font-size: 34px!important;margin-top: 30px;">
                                                           Plants
                                                       </div>
                                                       </div>
                                                       </div>
                                            <div class="row rowapd catEventHomeWithTitle max-container" style=" margin: 0 auto!important;padding-top: 0px;">
                                                 <div class="col l12 s12 m12" style="padding:0;margin:0 auto;margin-top: -11px;margin-bottom: 5px;">
                                                    <div class=" col l4 s4 desktop-left-title">
                                                   </div>
                                                   <div class=" col l4 s4 desktop-left-title">
                                                       <div class="color: #333333;" style="text-align: center;font-size: 27px;font-weight: 500;">Add greens to your living space</div>
                                                   </div>
                                                   <a  style="color:white" href="plants.html">
                                                       <div class="col l4 s4 justifyEndClass" style="justify-content: end;display: flex;padding-left: 0px;">
                                                                                    <span class="view_all_multiple"> VIEW ALL </span>
                                                                                 </div>
                                                   </a>
                                               </div>
                                <div class="adobeEventPos col s3 l3 m3 padding-vl">
                                    <a class="center-align" href="plants/indoor.html">
                                        <div class="card " style='border-radius:14px;box-shadow:none;overflow:hidden;margin:0;background-color: #FFFFFF!important;'>
                                            <div class="card-image">
                                                <img  alt="Indoor Plants" loading ="lazy" widgetType="plant category"  class=" lazyload responsive-img " src="{{asset('assets/website/groot/2024/04/16/desktop/three-hundred-eighty-five-into-three-hundred-fifty-five.gif')}}" data-src="https://externalassets/groot/2023/12/18/desktop/indoor-plants.jpg?w=385" style="width:100%;height:100%">
                                                <div class="card-content col l12 s12 m12" style='padding: 17px 0px 13px;padding-top: 2px;'>
                                                    <div class=" col l12 s12 m12 truncate" style='padding-right: 0;text-align:center;color:#404040;line-height:19px;background: #FFFFFF 0% 0% no-repeat padding-box;
                                                                                                                                                                      border: 1px solid #e8e8e8;
                                                                                                                                                                      border-radius: 0px 0px 15px 15px;
                                                                                                                                                                      border-top: 0px;
                                                                                                                                                                          padding-bottom: 12px;'>
                                                        <span style="font-size: 18px;display:block;font-weight:800;text-align: center;padding-top: 12px;padding-bottom: 7px;">Indoor Plants </span>
                                                        <span style='font-size:15px;'>Starting From</span>
                                                        <span style='font-size:15px;' class="moneySymbol">₹ </span>
                                                        <span style='font-size:15px;'  class="moneyCal" data-inr="325">325</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <div class="adobeEventPos col s3 l3 m3 padding-vl">
                                    <a class="center-align" href="plants/air-purifier.html">
                                        <div class="card " style='border-radius:14px;box-shadow:none;overflow:hidden;margin:0;background-color: #FFFFFF!important;'>
                                            <div class="card-image">
                                                <img  alt="Outdoor Plants" loading ="lazy" widgetType="plant category" class=" lazyload responsive-img " src="{{asset('assets/website/groot/2024/04/16/desktop/three-hundred-eighty-five-into-three-hundred-fifty-five.gif')}}" data-src="https://externalassets/groot/2023/12/18/desktop/air-purifier-plants.jpg?w=385" style="width:100%;height:100%">
                                                <div class="card-content col l12 s12 m12" style='padding: 17px 0px 13px;padding-top: 2px;'>
                                                    <div class=" col l12 s12 m12 truncate" style='padding-right: 0;text-align:center;color:#404040;line-height:19px;background: #FFFFFF 0% 0% no-repeat padding-box;
                                                                                                                                                                      border: 1px solid #e8e8e8;
                                                                                                                                                                      border-radius: 0px 0px 15px 15px;
                                                                                                                                                                      border-top: 0px;
                                                                                                                                                                          padding-bottom: 12px;'>
                                                        <span style="font-size: 18px;display:block;font-weight:800;text-align: center;padding-top: 12px;padding-bottom: 7px;">Air Purifier Plants</span>
                                                        <span style='font-size:15px;'>Starting From</span>
                                                        <span style='font-size:15px;' class="moneySymbol">₹ </span>
                                                        <span style='font-size:15px;'  class="moneyCal" data-inr="325">325</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <div class="adobeEventPos col s3 l3 m3 padding-vl">
                                    <a class="center-align" href="plants/bamboo.html">
                                        <div class="card " style='border-radius:14px;box-shadow:none;overflow:hidden;margin:0;background-color:#FFFFFF!important;'>
                                            <div class="card-image">
                                                <img loading ="lazy"  alt="Air Purifier Plants" widgetType="plant category" class=" lazyload responsive-img " src="{{asset('assets/website/groot/2024/04/16/desktop/three-hundred-eighty-five-into-three-hundred-fifty-five.gif')}}" data-src="https://externalassets/groot/2023/12/18/desktop/lucky-bamboo.jpg?w=385"  style="width:100%;height:100%">
                                                <div class="card-content col l12 s12 m12" style='padding: 17px 0px 13px;padding-top: 2px;'>
                                                    <div class=" col l12 s12 m12 truncate" style='padding-right: 0;text-align:center;color:#404040;line-height:19px;background: #FFFFFF 0% 0% no-repeat padding-box;
                                                                                                                                                                      border: 1px solid #e8e8e8;
                                                                                                                                                                      border-radius: 0px 0px 15px 15px;
                                                                                                                                                                      border-top: 0px;
                                                                                                                                                                          padding-bottom: 12px;'>
                                                        <span style="font-size: 18px;display:block;font-weight:800;text-align: center;padding-top: 12px;padding-bottom: 7px;">Lucky Bamboo </span>
                                                        <span style='font-size:15px;'>Starting From</span>
                                                        <span style='font-size:15px;' class="moneySymbol">₹ </span>
                                                        <span style='font-size:15px;'  class="moneyCal" data-inr="479">479</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <div class="adobeEventPos col s3 l3 m3 padding-vl">
                                    <a class="center-align" href="plants/money.html">
                                        <div class="card " style='border-radius:14px;box-shadow:none;overflow:hidden;margin:0;background-color:#FFFFFF!important;'>
                                            <div class="card-image">
                                                <img alt="Flowering Plants" loading ="lazy" widgetType="plant category" class=" lazyload responsive-img " src="{{asset('assets/website/groot/2024/04/16/desktop/three-hundred-eighty-five-into-three-hundred-fifty-five.gif')}}" data-src="https://externalassets/groot/2023/12/18/desktop/money-plants.jpg?w=385" style="width:100%;height:100%">
                                                <div class="card-content col l12 s12 m12" style='padding: 17px 0px 13px;padding-top: 2px;'>
                                                    <div class=" col l12 s12 m12 truncate" style='padding-right: 0;text-align:center;color:#404040;line-height:19px;background: #FFFFFF 0% 0% no-repeat padding-box;
                                                                                                                                                                      border: 1px solid #e8e8e8;
                                                                                                                                                                      border-radius: 0px 0px 15px 15px;
                                                                                                                                                                      border-top: 0px;
                                                                                                                                                                          padding-bottom: 12px;'>
                                                        <span style="font-size: 18px;display:block;font-weight:800;text-align: center;padding-top: 12px;padding-bottom: 7px;">Money Plants </span>
                                                        <span style='font-size:15px;'>Starting From</span>
                                                        <span style='font-size:15px;' class="moneySymbol">₹ </span>
                                                        <span style='font-size:15px;'  class="moneyCal" data-inr="399">399</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            </div>


            <div id="Tab4" class="content">
                    <div class="your-slider-class">
                            </div>
            </div>

<div id="colorChange" class="addColorForPlant container" style="border-radius: 20px;padding-top: 43px;padding-bottom: 12px;margin-top: 40px;margin: 25px 25px 8px;margin:0 auto!important;max-width: 1540px;padding-bottom:3%!important;">
<div class="row" style="padding-left: 77px;">
<div style="position:relative;margin-top: -4px;"><span class="bottomLineDesign" style="font-size: 14px;"></span></div>
<div class="col m2 l2 bestsellerFont" style="font-size: 37px;font-weight: 900!important;">Bestsellers</div>
 <div class="col">  <div  id="plantTab" class="custom-tab active plantActiveTab" onclick="openCustomTab('customTab1')" onKeyPress="handleKeyPress(event)" onKeyDown="handleKeyDown(event)" onKeyUp="handleKeyUp(event)" style="width:100%;padding: 6px 30px 6px;font-size: 25px;border-radius:5px 5px 0px 0px;position:relative;background: #FFFFFF 0% 0% no-repeat padding-box;border: 1px solid #CBCBCB;font-weight:900;">Plants
 <img id="arrowImagePlant" src="{{asset('assets/website/groot/2023/12/18/desktop/downword-errow.png')}}" alt="Arrow" style="position: absolute; bottom: -10px; left: 50%; transform: translateX(-50%);">

 </div></div>
   <div class="col"> <div id="chocolateTab"  class="custom-tab" onclick="openCustomTab('customTab2')" onKeyPress="handleKeyPress(event)" onKeyDown="handleKeyDown(event)" onKeyUp="handleKeyUp(event)" style="width:100%;padding: 6px 30px 6px;font-size: 25px;border-radius:5px 5px 0px 0px;position:relative;background: #FFFFFF 0% 0% no-repeat padding-box;border: 1px solid #CBCBCB;font-weight:900;">Chocolates
          <img id="arrowImageChocolate" src="{{asset('assets/website/groot/2023/12/18/desktop/downword-errow.png')}}" alt="Arrow" style="position: absolute; bottom: -10px; left: 50%; transform: translateX(-50%);display:none;">

   </div></div>
   <div class="col"> <div id="comboTab" class="custom-tab" onclick="openCustomTab('customTab3')" onKeyPress="handleKeyPress(event)" onKeyDown="handleKeyDown(event)" onKeyUp="handleKeyUp(event)" style="width:100%;padding: 6px 30px 6px;font-size: 25px;border-radius:5px 5px 0px 0px;position:relative;background: #FFFFFF 0% 0% no-repeat padding-box;border: 1px solid #CBCBCB;font-weight:900;">Combos
                     <img id="arrowImageCombo" src="{{asset('assets/website/groot/2023/12/18/desktop/downword-errow.png')}}" alt="Arrow" style="position: absolute; bottom: -10px; left: 50%; transform: translateX(-50%);display:none;">

          </div></div>
   <div> <div class="plantViewButton"  style="width:100%;padding: 10px 45px 10px;font-size: 25px;text-align:right;padding-right: 6%;position:relative;"> <a class="center-align" href="plants.html"><span style=" background: #B1E6A8 0% 0% no-repeat padding-box;border: 1px solid #E6E6E6;border-radius: 5px;padding: 8px 16px;font-size: 17px;font-weight: 600;position: absolute;right: 92px;top: 1px;color: #22181C;">VIEW ALL</span>  </a></div></div>

    <div> <div class="chocolateViewButton"  style="width:100%;padding: 10px 45px 10px;font-size: 25px;text-align:right;padding-right: 6%;display:none;position:relative;">  <a class="center-align" href="chocolates.html"><span style=" background: #D2B8A4 0% 0% no-repeat padding-box;border: 1px solid #E6E6E6;border-radius: 5px;padding: 8px 16px;font-size: 17px;font-weight: 600;position: absolute;right: 92px;top: 1px;color: #22181C;">VIEW ALL</span>  </a></div></div>

<div> <div class="comboViewButton"  style="width:100%;padding: 10px 45px 10px;font-size: 25px;text-align:right;padding-right: 6%;display:none;position:relative;">    <a class="center-align" href="combos.html"><span style="background: #FFE085 0% 0% no-repeat padding-box;border: 1px solid #E6E6E6;border-radius: 5px;padding: 8px 16px;font-size: 17px;font-weight: 600;position: absolute;right: 92px;top: 1px;color: #22181C;">VIEW ALL</span> </a></div></div>
</div>


<div id="customTab1" class="custom-tab-content active tabWidth" style="width: 89%!important;margin: 0 auto!important;">

<div class="bestsellerPlants">
<div class="col m12 s12 l12" style="text-align: center;">
     <img  class="preloderForImage" src="{{asset('assets/website/groot/2022/12/26/desktop/processing-gif-second.gif')}}" alt="processing-gif-second" />
 </div>
</div>
</div>

<div id="customTab2" class="custom-tab-content tabWidth" style="width: 89%!important;margin: 0 auto!important;">
       <div class="bestsellerChocolate">
           <div class="col m12 s12 l12" style="text-align: center;">
                 <img  class="preloderForImage" src="{{asset('assets/website/groot/2022/12/26/desktop/processing-gif-second.gif')}}" alt="processing-gif-second"/>
             </div>
       </div>
</div>


<div id="customTab3" class="custom-tab-content tabWidth" style="width: 89%!important;margin: 0 auto!important;">
      <div class="bestsellerCombos">
             <div class="col m12 s12 l12" style="text-align: center;">
                 <img class="preloderForImage" src="{{asset('assets/website/groot/2022/12/26/desktop/processing-gif-second.gif')}}" alt="processing-gif-second"/>
             </div>
      </div>
</div>

</div>



             <div class="row catEventHomeWithTitle max-container" style=" margin: 0 auto!important;padding-top:0px!important;margin-top: -10px;">
                                                <div class="col l12 s12 m12" style="padding:0;margin-bottom:6px;margin:0 auto;">
                                                    <div class="desktop-left-title" style="text-align: center;font-size: 34px!important;margin-top: 60px;">
                                                         Chocolates
                                                    </div>
                                                    </div>
                                                    </div>
                            <div class="row rowapd catEventHomeWithTitle max-container" style=" margin: 0 auto!important;padding-top:0px!important;">
                                <div class="col l12 s12 m12" style="padding:0;margin-bottom:6px;margin:0 auto;margin-top: -10px;margin-bottom: 8px;">
                                     <div class=" col l4 s4 desktop-left-title">
                                    </div>
                                    <div class=" col l4 s4 desktop-left-title" style="    font-size: 19px!important;">
                                        <div style="text-align: center;font-size: 27px;font-weight: 500;">Sweet Temptations to Share</div>
                                    </div>
                                    <a  style="color:white" href="chocolates.html">
                                       <div class="col l4 s4 justifyEndClass" style="justify-content: end;display: flex;padding-left: 0px;">
                                            <span class="view_all_multiple"> VIEW ALL </span>
                                         </div>
                                    </a>
                                </div>
                <div class="adobeEventPos col s3 l3 m3 padding-vl" style="padding: 17px 16px 17px;">
                    <a class="center-align" href="personalised-gifts/chocolate.html">
                        <div class="card " style='border-radius:14px;box-shadow:none;overflow:hidden;margin:0;background-color: #FFFFFF!important;'>
                            <div class="card-image">
                                <img   alt="Chocolate Combos" widgetType="chocolate category" class=" lazyload responsive-img " src="{{asset('assets/website/groot/2024/04/08/desktop/spinner00b9.gif')}}?w=385" data-src="https://externalassets/groot/2023/12/18/desktop/personalised-chocolates.jpg?w=385" style="width:100%;height:100%">
                                <div class="card-content col l12 s12 m12" style='padding: 17px 0px 13px;padding-top: 0px;'>
                                    <div class=" col l12 s12 m12 truncate" style='padding-right: 0;text-align: center;color:#404040;line-height:19px;background: #FFFFFF 0% 0% no-repeat padding-box;
                                                                                                                                                         border: 1px solid #e8e8e8;
                                                                                                                                                         border-radius: 0px 0px 15px 15px;
                                                                                                                                                         border-top: 0px;
                                                                                                                                                         padding-bottom: 13px;'>
                                        <span style="font-size:17px;display:block;font-weight:800;padding-top: 12px;padding-bottom: 7px;">Personalised Chocolates</span>
                                        <span style='font-size:13px;'>Starting From</span>
                                        <span style='font-size:13px;' class="moneySymbol">₹ </span>
                                        <span style='font-size:13px;'  class="moneyCal" data-inr="549">549</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="adobeEventPos col s3 l3 m3 padding-vl">
                    <a class="center-align" href="chocolate-bouquet.html">
                        <div class="card " style='border-radius:14px;box-shadow:none;overflow:hidden;margin:0;background-color: #FFFFFF!important;'>
                            <div class="card-image">
                                <img   alt="Chocolate Bouquet " widgetType="chocolate category" class=" lazyload responsive-img " src="{{asset('assets/website/groot/2024/04/08/desktop/spinner00b9.gif')}}?w=385" data-src="https://externalassets/groot/2023/12/18/desktop/chocolates-bouquet.jpg?w=385" style="width:100%;height:100%">
                                <div class="card-content col l12 s12 m12" style='padding: 17px 0px 13px;padding-top: 0px;'>
                                    <div class=" col l12 s12 m12 truncate" style='padding-right: 0;text-align: center;color:#404040;line-height:19px;    background: #FFFFFF 0% 0% no-repeat padding-box;
                                                                                                                                                         border: 1px solid #e8e8e8;
                                                                                                                                                         border-radius: 0px 0px 15px 15px;
                                                                                                                                                         border-top: 0px;
                                                                                                                                                         padding-bottom: 13px;'>
                                        <span style="font-size:17px;display:block;font-weight:800;padding-top: 12px;padding-bottom: 7px;">Chocolate Bouquet </span>
                                        <span style='font-size:13px;'>Starting From</span>
                                        <span style='font-size:13px;' class="moneySymbol">₹ </span>
                                        <span style='font-size:13px;'  class="moneyCal" data-inr="599">599</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="adobeEventPos col s3 l3 m3 padding-vl">
                    <a class="center-align" href="chocolates/winni-exclusive.html">
                        <div class="card " style='border-radius:14px;box-shadow:none;overflow:hidden;margin:0;background-color:#FFFFFF!important;'>
                            <div class="card-image">
                                <img loading ="lazy"  alt="Cadbury Chocolates" widgetType="chocolate category" class=" lazyload responsive-img " src="{{asset('assets/website/groot/2024/04/08/desktop/spinner00b9.gif')}}?w=385" data-src="https://externalassets/groot/2023/12/18/desktop/winni-exclusive.jpg?w=385" style="width:100%;height:100%">
                                <div class="card-content col l12 s12 m12" style='padding: 17px 0px 13px;padding-top: 0px;'>
                                    <div class=" col l12 s12 m12 truncate" style='padding-right: 0;text-align: center;color:#404040;line-height:19px;    background: #FFFFFF 0% 0% no-repeat padding-box;
                                                                                                                                                         border: 1px solid #e8e8e8;
                                                                                                                                                         border-radius: 0px 0px 15px 15px;
                                                                                                                                                         border-top: 0px;
                                                                                                                                                         padding-bottom: 13px;'>
                                        <span style="font-size:17px;display:block;font-weight:800;padding-top: 12px;padding-bottom: 7px;">Winni Exclusive Chocolates  </span>
                                        <span style='font-size:13px;'>Starting From</span>
                                        <span style='font-size:13px;' class="moneySymbol">₹ </span>
                                        <span style='font-size:13px;'  class="moneyCal" data-inr="199">199</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="adobeEventPos col s3 l3 m3 padding-vl">
                    <a class="center-align" href="chocolates/hampers.html">
                        <div class="card " style='border-radius:14px;box-shadow:none;overflow:hidden;margin:0;background-color:#FFFFFF!important;'>
                            <div class="card-image">
                                <img alt="Sugar Free Chocolates" loading ="lazy" widgetType="chocolate category"  class=" lazyload responsive-img " src="{{asset('assets/website/groot/2024/04/08/desktop/spinner00b9.gif')}}?w=385" data-src="https://externalassets/groot/2023/12/18/desktop/chocolate-hampers.jpg?w=385" style="width:100%;height:100%">
                                <div class="card-content col l12 s12 m12" style='padding: 17px 0px 13px;padding-top: 0px;'>
                                    <div class=" col l12 s12 m12 truncate" style='padding-right: 0;text-align: center;color:#404040;line-height:19px;background: #FFFFFF 0% 0% no-repeat padding-box;
                                                                                                                                                         border: 1px solid #e8e8e8;
                                                                                                                                                         border-radius: 0px 0px 15px 15px;
                                                                                                                                                         border-top: 0px;
                                                                                                                                                         padding-bottom: 13px;'>
                                        <span style="font-size:17px;display:block;font-weight:800;padding-top: 12px;padding-bottom: 7px;">Chocolate Hampers </span>
                                        <span style='font-size:13px;'>Starting From</span>
                                        <span style='font-size:13px;' class="moneySymbol">₹ </span>
                                        <span style='font-size:13px;'  class="moneyCal" data-inr="1,099">1,099</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>


            <div class="row rowapd catEventHomeWithTitle max-container" style=" margin: 0 auto!important;padding-top:30px!important;padding-left: 15px;padding-right: 17px;">
                <div class="col l12 s12 m12" style="padding:0;margin-bottom:6px;margin:0 auto">
                    <div class="col l12 s12 desktop-left-title" style="text-align:center;font-size: 34px!important;margin-top: -14px;margin-bottom: 8px;">
                       Gift Categories
                    </div>

                </div>
                <div class="adobeEventPos col s3 l3 m3 " style="padding: 0 9px 32px">
                    <a class="center-align" href="personalised-gifts/mugs.html">
                        <div class="card " style='border-radius:14px;box-shadow:none;overflow:hidden;margin:0;background-color: #FFFFFF!important;'>
                            <div class="card-image">
                                <img alt="Jewellery" loading ="lazy" widgetType="explore more categories" class=" lazyload responsive-img " src="{{asset('assets/website/groot/2024/04/08/desktop/spinner.gif')}}" data-src="https://externalassets/groot/2023/12/18/desktop/mugs.jpg?w=385" style="width:100%;height:100%">
                                <div class="card-content col l12 s12 m12" style='padding: 17px 0px 13px;padding-top: 0px;'>
                                    <div class=" col l12 s12 m12 truncate" style='padding-right: 0;text-align:center;color:#404040;line-height:19px;background: #FAFAFA 0% 0% no-repeat padding-box;
                                                                                                                                                      border: 1px solid #e1e1e1;
                                                                                                                                                      border-radius: 0px 0px 15px 15px;
                                                                                                                                                      border-top: 0px;
                                                                                                                                                         padding-bottom: 16px;
                                                                                                                                                         padding-top: 16px;'>
                                        <span style="font-size:17px;display:block;font-weight:800">Mugs  </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="adobeEventPos col s3 l3 m3 " style="padding: 0 9px 32px!important">
                    <a class="center-align" href="personalised-gifts/cushions.html">
                        <div class="card " style='border-radius:14px;box-shadow:none;overflow:hidden;margin:0;background-color: #FFFFFF!important;'>
                            <div class="card-image">
                                <img alt="Personalised Mugs" loading ="lazy" widgetType="explore more categories" class=" lazyload responsive-img " src="{{asset('assets/website/groot/2024/04/08/desktop/spinner.gif')}}" data-src="https://externalassets/groot/2023/12/18/desktop/cushions.jpg?w=385" style="width:100%;height:100%">
                                <div class="card-content col l12 s12 m12" style='padding: 17px 0px 13px;padding-top: 0px;'>
                                    <div class="  col l12 s12 m12 truncate" style='padding-right: 0;text-align:center;color:#404040;line-height:19px;background: #FAFAFA 0% 0% no-repeat padding-box;
                                                                                                                                                      border: 1px solid #e1e1e1;
                                                                                                                                                      border-radius: 0px 0px 15px 15px;
                                                                                                                                                      border-top: 0px;
                                                                                                                                                         padding-bottom: 16px;
                                                                                                                                                         padding-top: 16px;'>
                                        <span style="font-size:17px;display:block;font-weight:800">Cushions </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="adobeEventPos col s3 l3 m3 " style="padding: 0 9px 32px!important">
                    <a class="center-align" href="personalised-gifts/photo-frames.html">
                        <div class="card " style='border-radius:14px;box-shadow:none;overflow:hidden;margin:0;background-color:#FFFFFF!important;'>
                            <div class="card-image">
                                <img  alt="Accessories" loading ="lazy" widgetType="explore more categories" class=" lazyload responsive-img " src="{{asset('assets/website/groot/2024/04/08/desktop/spinner00b9.gif')}}?w=385" data-src="https://externalassets/groot/2023/12/18/desktop/photo-frames.jpg?w=385" style="width:100%;height:100%">
                                <div class="card-content col l12 s12 m12" style='padding: 17px 0px 13px;    padding-top: 0px;'>
                                    <div class="  col l12 s12 m12 truncate" style='padding-right: 0;text-align:center;color:#404040;line-height:19px;background: #FAFAFA 0% 0% no-repeat padding-box;
                                                                                                                                                      border: 1px solid #e1e1e1;
                                                                                                                                                      border-radius: 0px 0px 15px 15px;
                                                                                                                                                      border-top: 0px;
                                                                                                                                                         padding-bottom: 16px;
                                                                                                                                                         padding-top: 16px;'>
                                        <span style="font-size:17px;display:block;font-weight:800">Photo Frames  </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="adobeEventPos col s3 l3 m3 " style="padding: 0 7px 32px!important">
                    <a class="center-align" href="gifts/jewellery.html">
                        <div class="card " style='border-radius:14px;box-shadow:none;overflow:hidden;margin:0;background-color:#FFFFFF!important;'>
                            <div class="card-image">
                                <img  alt="Home Decor" loading ="lazy" widgetType="explore more categories" class=" lazyload responsive-img " src="{{asset('assets/website/groot/2024/04/08/desktop/spinner00b9.gif')}}?w=385" data-src="https://externalassets/groot/2023/12/18/desktop/jewellery.jpg?w=385" style="width:100%;height:100%">
                                <div class="card-content col l12 s12 m12" style='padding: 17px 0px 13px;    padding-top: 0px;'>
                                    <div class="  col l12 s12 m12 truncate" style='padding-right: 0;text-align:center;color:#404040;line-height:19px;background: #FAFAFA 0% 0% no-repeat padding-box;
                                                                                                                                                      border: 1px solid #e1e1e1;
                                                                                                                                                      border-radius: 0px 0px 15px 15px;
                                                                                                                                                      border-top: 0px;
                                                                                                                                                         padding-bottom: 16px;
                                                                                                                                                         padding-top: 16px;'>
                                        <span style="font-size:17px;display:block;font-weight:800">Jewellery  </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="adobeEventPos col s3 l3 m3 padding-vl" style="padding: 0 7px 32px;margin-bottom:25px;">
                    <a class="center-align" href="gifts/home-decor.html">
                        <div class="card " style='border-radius:14px;box-shadow:none;overflow:hidden;margin:0;background-color: #FFFFFF!important;'>
                            <div class="card-image">

                                <img  alt="Handbags" loading ="lazy" widgetType="explore more categories"  class=" lazyload responsive-img " src="{{asset('assets/website/groot/2024/04/08/desktop/spinner00b9.gif')}}?w=385" data-src="https://externalassets/groot/2023/12/18/desktop/home-decor.jpg?w=385" style="width:100%;height:100%">
                                <div class="card-content col l12 s12 m12" style='padding: 17px 0px 13px;    padding-top: 0px;'>
                                    <div class=" col l12 s12 m12 truncate" style='padding-right: 0;text-align:center;color:#404040;line-height:19px;background: #FAFAFA 0% 0% no-repeat padding-box;
                                                                                                                                                                          border: 1px solid #e1e1e1;
                                                                                                                                                                          border-radius: 0px 0px 15px 15px;
                                                                                                                                                                          border-top: 0px;
                                                                                                                                                                              padding-bottom: 16px;
                                                                                                                                                                              padding-top: 16px;'>
                                        <span style="font-size:17px;display:block;font-weight:800">Home Decor  </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="adobeEventPos col s3 l3 m3 padding-vl" style="padding: 0 7px 32px;margin-bottom:25px;">
                    <a class="center-align" href="gifts/led-frames.html">
                        <div class="card " style='border-radius:14px;box-shadow:none;overflow:hidden;margin:0;background-color: #FFFFFF!important;'>
                            <div class="card-image">
                                <img alt="Candles" loading ="lazy" widgetType="explore more categories"  class=" lazyload responsive-img " src="{{asset('assets/website/groot/2024/04/08/desktop/spinner00b9.gif')}}?w=385" data-src="https://externalassets/groot/2023/12/18/desktop/led-frames.jpg?w=385" style="width:100%;height:100%">
                                <div class="card-content col l12 s12 m12" style='padding: 17px 0px 13px;    padding-top: 0px;'>
                                    <div class="  col l12 s12 m12 truncate" style='padding-right: 0;text-align:center;color:#404040;line-height:19px;background: #FAFAFA 0% 0% no-repeat padding-box;
                                                                                                                                                      border: 1px solid #e1e1e1;
                                                                                                                                                      border-radius: 0px 0px 15px 15px;
                                                                                                                                                      border-top: 0px;
                                                                                                                                                          padding-bottom: 16px;
                                                                                                                                                          padding-top: 16px;'>
                                        <span style="font-size:17px;display:block;font-weight:800">Led Frames </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="adobeEventPos col s3 l3 m3 padding-vl" style="padding: 0 7px 32px;margin-bottom:25px;">
                    <a class="center-align" href="personalised-gifts/stationery.html">
                        <div class="card " style='border-radius:14px;box-shadow:none;overflow:hidden;margin:0;background-color:#FFFFFF!important;'>
                            <div class="card-image">
                                <img alt="Handmade Gifts" loading ="lazy" widgetType="explore more categories" class=" lazyload responsive-img " src="{{asset('assets/website/groot/2024/04/08/desktop/spinner00b9.gif')}}?w=385" data-src="https://externalassets/groot/2023/12/18/desktop/stationary-gifts.jpg?w=385" style="width:100%;height:100%">
                                <div class="card-content col l12 s12 m12" style='padding: 17px 0px 13px;    padding-top: 0px;'>
                                    <div class="  col l12 s12 m12 truncate" style='padding-right: 0;text-align:center;color:#404040;line-height:19px;background: #FAFAFA 0% 0% no-repeat padding-box;
                                                                                                                                                      border: 1px solid #e1e1e1;
                                                                                                                                                      border-radius: 0px 0px 15px 15px;
                                                                                                                                                      border-top: 0px;
                                                                                                                                                          padding-bottom: 16px;
                                                                                                                                                          padding-top: 16px;'>
                                        <span style="font-size:17px;display:block;font-weight:800">Stationery Gifts   </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="adobeEventPos col s3 l3 m3 padding-vl" style="padding: 0 7px 32px;margin-bottom:25px;">
                    <a class="center-align" href="sweets.html">
                        <div class="card " style='border-radius:14px;box-shadow:none;overflow:hidden;margin:0;background-color:#FFFFFF!important;'>
                            <div class="card-image">
                                <img  alt="Utensils" loading ="lazy" widgetType="explore more categories" class=" lazyload responsive-img "  src="{{asset('assets/website/groot/2024/04/08/desktop/spinner00b9.gif')}}?w=385" data-src="https://externalassets/groot/2023/12/18/desktop/sweets.jpg?w=385" style="width:100%;height:100%">
                                <div class="card-content col l12 s12 m12" style='padding: 17px 0px 13px;    padding-top: 0px;'>
                                    <div class=" col l12 s12 m12 truncate" style='padding-right: 0;text-align:center;color:#404040;line-height:19px;background: #FAFAFA 0% 0% no-repeat padding-box;
                                                                                                                                                      border: 1px solid #e1e1e1;
                                                                                                                                                      border-radius: 0px 0px 15px 15px;
                                                                                                                                                      border-top: 0px;
                                                                                                                                                          padding-bottom: 16px;
                                                                                                                                                          padding-top: 16px;'>
                                        <span style="font-size:17px;display:block;font-weight:800">Sweets</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="adobeEventPos col s3 l3 m3 padding-vl">
                    <a class="center-align" href="dry-fruits.html">
                        <div class="card " style='border-radius:14px;box-shadow:none;overflow:hidden;margin:0;background-color:#FFFFFF!important;'>
                            <div class="card-image">
                                <img  alt="Utensils" loading ="lazy" widgetType="explore more categories" class=" lazyload responsive-img "  src="{{asset('assets/website/groot/2024/04/08/desktop/spinner.gif')}}" data-src="https://externalassets/groot/2023/12/18/desktop/dryfruits.jpg?w=385" style="width:100%;height:100%">
                                <div class="card-content col l12 s12 m12" style='padding: 17px 0px 13px;    padding-top: 0px;'>
                                    <div class=" col l12 s12 m12 truncate" style='padding-right: 0;text-align:center;color:#404040;line-height:19px;background: #FAFAFA 0% 0% no-repeat padding-box;
                                                                                                                                                    border: 1px solid #e1e1e1;
                                                                                                                                                      border-radius: 0px 0px 15px 15px;
                                                                                                                                                      border-top: 0px;
                                                                                                                                                          padding-bottom: 16px;
                                                                                                                                                          padding-top: 16px;'>
                                        <span style="font-size:17px;display:block;font-weight:800">Dryfruits</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="adobeEventPos col s3 l3 m3 padding-vl">
                    <a class="center-align" href="gifts/handbags.html">
                        <div class="card " style='border-radius:14px;box-shadow:none;overflow:hidden;margin:0;background-color:#FFFFFF!important;'>
                            <div class="card-image">
                                <img  alt="Utensils" loading ="lazy" widgetType="explore more categories" class=" lazyload responsive-img " src="{{asset('assets/website/groot/2024/04/08/desktop/spinner00b9.gif')}}?w=385" data-src="https://externalassets/groot/2023/12/18/desktop/handbags-wallets.jpg?w=385" style="width:100%;height:100%">
                                <div class="card-content col l12 s12 m12" style='padding: 17px 0px 13px;    padding-top: 0px;'>
                                    <div class=" col l12 s12 m12 truncate" style='padding-right: 0;text-align:center;color:#404040;line-height:19px;background: #FAFAFA 0% 0% no-repeat padding-box;
                                                                                                                                                      border: 1px solid #e1e1e1;
                                                                                                                                                      border-radius: 0px 0px 15px 15px;
                                                                                                                                                      border-top: 0px;
                                                                                                                                                          padding-bottom: 16px;
                                                                                                                                                          padding-top: 16px;'>
                                        <span style="font-size:17px;display:block;font-weight:800">Handbags & Wallets</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="adobeEventPos col s3 l3 m3 padding-vl">
                    <a class="center-align" href="gifts/glassware.html">
                        <div class="card " style='border-radius:14px;box-shadow:none;overflow:hidden;margin:0;background-color:#FFFFFF!important;'>
                            <div class="card-image">
                                <img  alt="Utensils" loading ="lazy" widgetType="explore more categories" class=" lazyload responsive-img " src="{{asset('assets/website/groot/2024/04/08/desktop/spinner00b9.gif')}}?w=385" data-src="https://externalassets/groot/2023/12/18/desktop/glassware.jpg?w=385" style="width:100%;height:100%">
                                <div class="card-content col l12 s12 m12" style='padding: 17px 0px 13px;    padding-top: 0px;'>
                                    <div class=" col l12 s12 m12 truncate" style='padding-right: 0;text-align:center;color:#404040;line-height:19px;background: #FAFAFA 0% 0% no-repeat padding-box;
                                                                                                                                                      border: 1px solid #e1e1e1;
                                                                                                                                                      border-radius: 0px 0px 15px 15px;
                                                                                                                                                      border-top: 0px;
                                                                                                                                                          padding-bottom: 16px;
                                                                                                                                                          padding-top: 16px;'>
                                        <span style="font-size:17px;display:block;font-weight:800">Glassware</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="adobeEventPos col s3 l3 m3 padding-vl">
                    <a class="center-align" href="balloon-decorations.html">
                        <div class="card " style='border-radius:14px;box-shadow:none;overflow:hidden;margin:0;background-color:#FFFFFF!important;'>
                            <div class="card-image">
                                <img  alt="Utensils" loading ="lazy" widgetType="explore more categories" class=" lazyload responsive-img " src="{{asset('assets/website/groot/2024/04/08/desktop/spinner00b9.gif')}}?w=385" data-src="https://externalassets/groot/2023/12/18/desktop/balloon-becoration.jpg?w=385" style="width:100%;height:100%">
                                <div class="card-content col l12 s12 m12" style='padding: 17px 0px 13px;    padding-top: 0px;'>
                                    <div class=" col l12 s12 m12 truncate" style='padding-right: 0;text-align:center;color:#404040;line-height:19px;background: #FAFAFA 0% 0% no-repeat padding-box;
                                                                                                                                                      border: 1px solid #e1e1e1;
                                                                                                                                                      border-radius: 0px 0px 15px 15px;
                                                                                                                                                      border-top: 0px;
                                                                                                                                                          padding-bottom: 16px;
                                                                                                                                                          padding-top: 16px;'>
                                        <span style="font-size:17px;display:block;font-weight:800">Balloon Decoration</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>

            </div>
    <div class="recentlyViewProductsSection" id="recentlyViewProductsSection">
    <div class="col m12 s12 l12" style="text-align: center;">
         <img  class="preloderForImage" src="{{asset('assets/website/groot/2022/12/26/desktop/processing-gif-second.gif')}}" alt="processing-gif-second"/>
     </div>
   </div>

         <div class="row center-align white catEventHomeWithTitle container" style='margin:0 auto;!important;color:#333333;margin:0 auto;padding-right: 0px;padding-left: 0px!important;'>
            <div class="col s12  desktop-left-title" style="text-align:center;font-weight: 600;font-size: 43px!important;margin-top: 15px;">International Gifts Delivery</div>
            <div class="col s2 adobeEventPos">
                <a href="australia.html" class="responsive-img ">
                    <img alt="australia" loading ="lazy"  widgetType="International" class=" responsive-img lazyload"  src="{{asset('assets/website/groot/2024/04/08/desktop/spinner.gif')}}" data-src="{{asset('assets/website/groot/2023/05/11/desktop/austrelia.png')}}"/>
                </a>
                <div class='text center-align internationalCountryFont'>Australia</div>
            </div>
            <div class="col s2 adobeEventPos">
                <a href="usa.html" class="responsive-img">
                    <img alt="usa" loading ="lazy"  widgetType="International" class=" responsive-img lazyload"  src="{{asset('assets/website/groot/2024/04/08/desktop/spinner.gif')}}" data-src="{{asset('assets/website/groot/2023/05/11/desktop/usa.png')}}"/>
                </a>
                <div class='text center-align internationalCountryFont'>USA</div>
            </div>
            <div class="col s2 adobeEventPos">
                <a href="canada.html" class="responsive-img ">
                    <img alt="canada" loading ="lazy"  widgetType="International"  class=" responsive-img lazyload"  src="{{asset('assets/website/groot/2024/04/08/desktop/spinner.gif')}}" data-src="{{asset('assets/website/groot/2023/05/11/desktop/canada.png')}}"/>
                </a>
                <div class= "text center-align internationalCountryFont">Canada</div>
            </div>
            <div class="col s2 adobeEventPos">
                <a href="uk.html" class="responsive-img ">
                    <img alt="uk" loading ="lazy"   widgetType="International"  class=" responsive-img lazyload"  src="{{asset('assets/website/groot/2024/04/08/desktop/spinner.gif')}}" data-src="{{asset('assets/website/groot/2023/05/11/desktop/uk.png')}}"/>
                </a>
                <div class='text center-align internationalCountryFont'>UK</div>
            </div>
            <div class="col s2 adobeEventPos">
                <a href="uae.html" class="responsive-img ">
                    <img alt="uae" loading ="lazy"  widgetType="International"  class=" responsive-img lazyload"  src="{{asset('assets/website/groot/2024/04/08/desktop/spinner.gif')}}" data-src="{{asset('assets/website/groot/2023/05/11/desktop/uae.png')}}"/>
                </a>
                <div class='text center-align internationalCountryFont'>UAE</div>
            </div>
            <div class="col s2 adobeEventPos">
                <a href="international-gifts-delivery.html">
                    <img alt="international gifts delivery" loading ="lazy"   widgetType="International" class=" lazyload responsive-img "  src="{{asset('assets/website/groot/2024/04/08/desktop/spinner.gif')}}" data-src="{{asset('assets/website/groot/2023/05/11/desktop/world.png')}}">
                </a>
                <div class='text center-align internationalCountryFont'>Worldwide</div>
            </div>
        </div>
            <div class="row container" style="margin:0 auto!important;">
                           <div class="catEventHome col s12 l12 m12  " style="padding: 65px 18px 0;">
            <div class="adobeEventPos">
                <a href="stores.html">
                    <img alt="stores" loading ="lazy" s bannerType="winni stores" class=" lazyload responsive-img "  src="{{asset('assets/website/groot/2024/04/08/desktop/spinner.gif')}}" data-src="https://externalassets/groot/2024/01/22/desktop/service-and-experience-banner-desktop-images.png?w=1570" style="border-radius:10px;width:100%;height:100%">
                </a>
            </div>
        </div>
        </div>
        </div>
        <div class="section container" style="margin:0 auto!important;">
            <div class="row">
                <div class="col s12 page-description-content">
                    <h1 style="text-align:center;">Winni - India’s No. 1 Brand for Online Delivery of Cakes, Flowers, And Gifts</h1><p dir="ltr">Winni is India’s leading platform that helps you celebrate relations by sending <a href="birthday-cakes.html">birthday cake</a>, flowers, chocolates, plants, gifts, as well as personalized gifts online. We operate irrespective of geographical barriers to mark your special days like birthdays, anniversaries,&nbsp;festivals such as Diwali, Holi, Christmas, Rakhi occasions like <a href="gifts/mothers-day.html">mothers day</a>, valentine day and fathers day in style. You can send your love and wishes to your dear ones miles away as we stand as a shining light for celebrations and heartfelt gestures.</p><p dir="ltr">Our strong online and offline presence along with our trusted delivery partners has made our service reach over 20,000 pin codes across 700 cities in India. So far, our exclusive range of goodies and online <a href="cake.html">cake&nbsp;delivery</a> services have satisfied over 20 million customers worldwide.</p><h2 dir="ltr">Pick ‘n’ Mix From Extensive Variety</h2><p dir="ltr">If you want to add a touch of sweetness to your celebrations, our precisely curated selection of cakes, blossoms, and gifts caters to every occasion and emotion. In addition, we are a great partner to remark on special occasions like Valentine’s Day, Mother’s Day, Father’s Day, or Children’s Day.</p><h2 dir="ltr">Cakes - To Celebrate Moments</h2><p dir="ltr">The party isn’t complete if everyone hasn’t stuffed their face with frosting. Cakes are slices of happiness that have the power to transform ordinary moments into extraordinary memories. Also, the world of cakes offers a delightful journey to be explored. Here’s what we dug out for you.</p><h3 dir="ltr">Cakes By Type</h3><p dir="ltr">The Winni bakehouse has all types of cake to make it the best centerpiece of your celebration. From personalized Photo Cakes to surprise-filled Pinata Cakes, we have got it all. The Heart-Shaped Cakes are perfect for romantic celebrations. To give you an overview, other than photo cake, pinata cake and&nbsp;heart-shaped cake, we have fondant cakes, kids cakes, premium cakes, <a href="eggless-cake.html">eggless cakes</a>, and pastries to satisfy your cravings. Winni has all the arrangements in place to <a href="cake/bangalore.html">deliver cakes in Bangalore</a>, Hyderabad, Mumbai, Pune, Delhi, Chennai, Kolkata or for that matter any city and town in india and abroad.&nbsp;</p><h3 dir="ltr">Cakes By Flavor</h3><p dir="ltr">We boast all cake flavors, ensuring a delectable choice for every dessert lover and taste to suit every celebration. To elevate your moments of joy, you can choose from timeless chocolate, delightful pineapple, rich butterscotch, classic vanilla, sweet &amp; tangy strawberry, explosive fruits, truffle indulgence, luxurious <a href="cake/red-velvet-cake.html">Red Velvet cake</a>, traditional Rasmalai, ever-popular Black Forest, and many other options. These heavenly treats will be the beginning of your ever-lasting memories.</p><h3 dir="ltr">Cakes By Theme</h3><p dir="ltr">The bakers at Winni have professionally crafted a wide assortment of theme cakes to turn your special moments into extraordinary memories. To name a few, our collection includes Superhero Cakes, <a href="cake/unicorn-cake.html">Unicorn Cakes</a>, Car Cakes, Number Cakes, Alphabet Cakes, Cartoon Cakes, Barbie Doll Cakes, as well as wedding cakes, and tier cakes. You can choose any theme that reflects your style and preferences. This will make your special day a feast for the eyes and a treat for the buds.</p><h3 dir="ltr">Cakes By Occasion</h3><p dir="ltr">Still looking for a birthday cake near me? Don’t! Because our delectable cakes are crafted to suit every occasion. Where every slice tells a story, our centerpiece will be the magic. Whether it's for a Birthday celebration, an Anniversary, a dreamy Wedding, a romantic Valentine's Day, a cherished Rakhi festival, a teachers day&nbsp;cake, a New Year's toast, or to embrace Christmas, we have the perfect cake to elevate all of your occasions and festivities.</p><h2 dir="ltr">Flowers: To Blossom Love</h2><p dir="ltr">Where words touch hearts, flowers reach souls. With their extraordinary ability to convey emotions, the vibrant colors make every moment enchanting especially <a href="roses.html">rose delivery</a> on valentine's day has the ability to change feelings and create new relations and memories. Just like our relations, they are fragile and beautiful, symbolizing love, elegance, and simplicity. Besides, they represent that relations require the same care as a delicate flower.</p><h3 dir="ltr">Flowers By Type</h3><p dir="ltr">The florist at Winni has a diverse and exquisite blooming selection catering to every preference and occasion. Whether you're expressing love, conveying sympathy, celebrating milestones, or simply brightening someone's day, our <a href="flowers.html">flowers</a> can speak the language of your heart. You can create meaningful moments with elegant roses,&nbsp; graceful Lilies, exotic Orchids, vibrant Gerberas, or the classic Carnations.</p><h3 dir="ltr">Flowers By Occasion</h3><p dir="ltr">It’s imperative to give the right flowers on every occasion. Impressively our array of blooms makes it easy to convey your sentiments, whatever the occasion might be. It could be a celebration like a birthday, anniversary, wedding, or simply to express your feelings of love and affection, sympathy, gratitude, congratulations, or well wishes. Our range of floral arrangements ensures that your message is conveyed with timeless beauty.</p><h3 dir="ltr">Flowers By Collection</h3><p dir="ltr">You can discover the exotic allure of our Exotic Flowers to create an unforgettable impression. Also, the delightful combination of our flower baskets and flower boxes showcases your wishes aesthetically. To win hearts at a single glance, our premium selection of flowers and flower bouquets will provide a luxurious heartwarming experience for both the sender and the recipient.</p><h3 dir="ltr">Flowers By Color</h3><p dir="ltr">Every color of flowers speaks its language of emotions. Therefore, we have crafted a colorful selection that speaks volumes. We have passionate red that signifies love, pink that represents affection, white that symbolizes grace &amp; purity, yellow for a bright life, and the enchanting purple speaking for royalty and success. Whereas, the mixed bouquet blends all colors, expressing a multitude of emotions in one vibrant arrangement.&nbsp;</p><h2 dir="ltr">Gifts: Something To Remember You By</h2><p dir="ltr">Everyone loves gifts, and of course, the person who gives gifts. They strengthen bonds and create lasting memories. Whether wrapped in colorful paper for a special occasion or shared as a spontaneous gesture, they represent your kind thoughts. To give gifts is to give smiles that can convey sentiments that words often cannot express.</p><h3 dir="ltr">Gifts By Type</h3><p dir="ltr">Besides flowers and cake, Winni also offers a diverse array of <a href="gifts.html">gifts</a> that cater to every taste and occasion. To begin with, you can order from a range of Personalized Gifts, Digital Gifts, Home Decor items, Personal Essentials, Photo Frames, Perfumes, Jewelry, Handbags, Caricatures, Soft Toys, and a lot more. With our endless options, you can easily find the perfect token of affection.</p><h3 dir="ltr">Gifts By Occasion</h3><p dir="ltr">If you are confused about what to gift your loved ones, Winni has a solution. Now, you can browse amazing presents for every imaginable occasion. Be it birthdays, anniversaries, wedding days, Valentine's Day, Rakhi,&nbsp; New Year, Christmas, Mother's Day, Father's Day, Children's Day, women's day or any other special moment, we have the perfect collection of gifts. With our selection, you can easily find the ideal, unique, and meaningful gifts.</p><h3 dir="ltr">Gifts By Recipient</h3><p dir="ltr">It’s a well-known fact that finding a gift for a man is comparatively tougher than looking for a present for a woman. But here at Winni, you can find gifts suitable for all types of recipients, regardless of gender. Our friendly collection caters to everyone's preferences and tastes. You can choose anything ranging from personalized gifts to trendy and practical items.</p><h3 dir="ltr">Corporate Gifts</h3><p dir="ltr">Apart from catering to individual gifting needs, Winni also understands the importance of corporate gifting. You can order corporate gifts in bulk for various special occasions. It could be a Diwali gift, a performance appreciation bonus, or simply a gesture of reinforcement for your valued team members. You can choose from a wide section that reflects your brand and appreciation for your employees or clients. This will keep the members actively engaged and foster stronger professional relationships.</p><h2 dir="ltr">Chocolates: The Edible Luxury</h2><p dir="ltr">In the chocolatey world of WInni, you can find a delightful variety of chocolate options to satisfy every craving and occasion. You can taste the exclusive sweetness of White Chocolate, the richness of Dark Chocolate, the crunch of Fruit 'n' Nut Chocolate, and much more at Winni. Moreover, to experience the allure of a sweet personal touch, get your hands on the Winni exclusive <a href="chocolates.html">Chocolates</a>. They are crafted with the richest flavors and purest love from the best Chocolatiers.</p><p dir="ltr">Additionally, our artfully arranged Chocolate Bouquets are a perfect presentation of a gift. They create a visual impression of your wishes. Adding an extra layer of fun, explore our captivating shapes and forms of chocolates like egg-shaped chocolates, bunny bunny-shaped chocolates, heart-shaped chocolates, and star-shaped chocolates. If you are a Weight Watcher, you can also indulge in our collection of sugar-free chocolate. In any form, the chocolates at Winni ensure that every bite becomes a moment of pure indulgence</p><h2 dir="ltr">Plants: To Seed Your Relationship</h2><p dir="ltr">Besides being guardians of the environment, plants can guard relationships too. To give a plant is like giving a living reminder of your affection, care, and warm wishes for growth and prosperity. Additionally, you’re not just giving them a present, you’re providing them with pure oxygen, fresh air, prosperity, and positive vibes.&nbsp; Beyond their aesthetic charm, each leaf and petal fosters a sustainable future for the environment and relations.</p><h3 dir="ltr">Plants By Type</h3><p dir="ltr">Besides celebrating relations, Winni also honors nature. That’s why we have a diverse range of plants to suit every household &amp; garden need. You can get indoor plants to bring a touch of nature to your living spaces or Outdoor Plants to enhance your garden's aesthetics. Other than this, the Flowering <a href="plants.html">Plants</a> can add charming and positive vibes to your surroundings. While Air Purifying Plants can bring a healthier indoor environment. Also, if you are not a plant enthusiast or want low-maintenance greenery, we also have Succulent Plants on board.</p><h3 dir="ltr">Plants By Occasion</h3><p dir="ltr">Winni believes that the gift of green and nature lasts forever. So, we have a gift that’ll nurture both your relationships and the environment. You can send blooming plants on birthdays, air-purifying plants for housewarming, indoor plants for anniversaries, outdoor plants for good luck, or succulent plants for Christmas. With any nature gift, you’re spreading love, positivity, and eco-friendliness</p><h3 dir="ltr">Plants By Placement</h3><p dir="ltr">We know plants bring prosperity, wealth, and good luck if they’re placed as per the vastu principles. That’s why we offer a selection of plants that will bring the charm with them. You can strategically place these plants in your living room, bedroom, tabletop, terrace, and balcony, to enhance the flow of positive energy. With these auspicious plants, the household will foster stronger relationships, stay away from financial issues, and bring well-being to its surroundings.</p><h2 dir="ltr">Gift Hampers and Combos For A Wholesome Celebration</h2><h3 dir="ltr">Cake And Chocolates</h3><p dir="ltr">Our carefully and beautifully arranged combo of delectable cakes and indulgent chocolates is perfect for sweet celebrations. They ensure a&nbsp; memorable taste experience for your special occasions. You can treat yourself or your loved ones with an extra layer of sweetness and joy adding to the festivities.</p><h3 dir="ltr">Cake And Teddy Bears</h3><p dir="ltr">Another sweet and delightful combo features a scrumptious combo and adorable teddy bears. This will add a little more warmth and affection to your celebrations. It can perfectly express your care, love, and affection for your special ones. Not to forget, this charming combination of sweetness and cuddles can bring out bright smiles.</p><h3 dir="ltr">Cake And Flowers</h3><p dir="ltr">The enchanting creation of scrumptious cake and vibrant flowers perfectly complement each other on special occasions. This present signifies sweetness and elegance, creating a heartwarming environment. To convey your warmest wishes gracefully, explore our section and make the day remarkable.</p><h3 dir="ltr">Flowers And Chocolates</h3><p dir="ltr">Our exquisite combo of fresh flowers and luxurious chocolates will make you experience the perfect balance of nature and sweetness. The carefully handpicked flowers and a variety of rich chocolates are ideal for expressing love, and gratitude, and celebrating a special occasion.</p><h3 dir="ltr">Flowers And Teddy Bears</h3><p dir="ltr">The multiple emotion of affection and care is represented by flowers and teddy bears. That’s why, we have a beautifully arranged combo of adorable teddy bears and a fragrance of exotic flowers. You can brighten someone's day, send get-well-soon wishes, or celebrate love with this affectionate gesture.</p><h3 dir="ltr">All In One</h3><p dir="ltr">The make the most of your day and occasion, the all-in-one combo encompasses the best of every world. It includes delectable cake, fresh flowers, indulgent chocolates, cuddly teddy bears, and a variety of gift options that you can choose from. This hamper is a thoughtful surprise that ensures your gift leaves an unforgettable impression.</p><h2 dir="ltr"><strong>Round-The-Clock Delivery Options&nbsp;</strong></h2><p dir="ltr">Winni takes pride in offering its customers round-the-clock delivery options, available every day of the week. Whether it's a weekday, weekend, or even a holiday, we are dedicated to ensuring that your special gifts are delivered to your loved ones at any time that suits your preferences. Even if your dear ones are in different time zones, you can still surprise them with timely gifts. Other than standard delivery, our options include express delivery, midnight delivery, <a href="cake/express-delivery.html">same-day cake delivery</a>, 2-hour delivery, and 30-minute delivery. Here’s what they mean!</p><h3 dir="ltr">30 Minutes Cake Delivery</h3><p dir="ltr">For the times when celebrations can’t wait, our lightning-fast 30-minute delivery option can fulfill your last-moment wishes. Your flowers, cake, and gifts will be right at your doorstep in just half an hour after order confirmation. In the blink of an eye, we can deliver you joy, swiftly, and reliably.</p><h3 dir="ltr">2-Hour Delivery of Cakes and Gifts and Flowers</h3><p dir="ltr">We believe in the power of punctuality, and that's why we offer an exceptional 2-Hour Delivery option. Whether it's a birthday, anniversary, or a spontaneous "thinking of you" moment, we can assist you in creating unforgettable moments with our 2-hour delivery guarantee.</p><h3 dir="ltr">Same-Day Delivery from Winni</h3><p dir="ltr">You can count on us to make every moment special with our reliable same-day delivery service. With your thoughtfulness and our 24-hour delivery option, you can brighten your dear one’s day in just a few minutes.&nbsp;</p><h3 dir="ltr">Midnight Cake Delivery</h3><p dir="ltr">We can unlock the magic of midnight moments with the midnight delivery service. Some celebrations such as birthdays or anniversaries are meant to begin precisely at the stroke of midnight. That’s why we can deliver your gifts from 11:00 PM to 11:59 PM under the cover of darkness.&nbsp;</p><h3 dir="ltr">Express Delivery</h3><p dir="ltr">Express delivery means exceptional speed. You can experience a swift delivery to celebrate moments that can’t wait. This rapid, reliable, and unforgettable service will certainly create an unforgettable gifting experience&nbsp;</p><h3 dir="ltr">Standard Delivery</h3><p dir="ltr">To offer you a perfect blend of reliability and affordability, we have a standard delivery option. This makes sure that your gifts reach your loved ones on time, without any unnecessary haste. Our delivery partner will transfer your gift with care and precision in a budget-friendly manner.</p><h2 dir="ltr">Commitment To Celebrate Relations Globally</h2><p dir="ltr">Winni is your one-stop destination for sending thoughtful gifts, beautiful flowers, delectable cakes&nbsp;and so much more to your loved ones, no matter where they are in the world. With a global presence, we promise to celebrate relations and ensure timely and hassle-free delivery to over 40 countries. Irrespective of the geographical boundaries, we can bridge the distance and help you create cherished memories with your loved ones.</p><p dir="ltr">No matter where your loved ones are scattered across the globe, you can send gifts to the USA, Canada, UAE, Australia, UK, New Zealand, Japan, Norway, Germany, Russia, and many other countries. Whether it's a birthday, anniversary, Valentine's Day, or any other meaningful moment, our services allow you to choose the perfect gesture to express your love and appreciation.&nbsp;</p><p dir="ltr">Furthermore, you can also send a picture of a birthday cake with name. As we know the world today, wishing and greeting publicly has become a trend. Besides, it feels good when someone is appreciating your presence in front of the world. To make your loved one feel special, get a virtual <a href="tlplist/birthday-cake-with-name.html">birthday cake with name</a> and post the picture on all social media platforms.</p><h2 dir="ltr">Seamless Browsing Experience via Winni Mobile App &amp; Website</h2><p dir="ltr">At Winni, we have invested in creating a seamless in-app and web browser experience that ensures effortless ordering. Our user-friendly website and app are designed to cater to your needs even if you're using a lower-model phone or have limited internet connectivity. The platforms are optimized for speed and efficiency, ensuring that you can smoothly explore our extensive collection of cakes, flowers, gifts, and more.&nbsp;</p><p dir="ltr">Winni app for Android and iOS offers incredible discounts, vouchers, and coupons, making it a go-to choice for over 500 thousand users. Our commitment to providing the best at a great price will add extra sweetness to your shopping experience. Moreover, our exclusive frequent discounts and special offers in the Winni app unlock the world of exclusive deals. This ensures that you find the perfect gift or treat for your loved ones without digging deep into your pockets.&nbsp;&nbsp;</p><h2 dir="ltr">Get Your Hands On Winni’s Franchise</h2><p dir="ltr">With a strong presence of over 350+&nbsp;retail stores throughout India, Winni offers an established platform for those looking to dive into the bakery industry. You can explore the exciting opportunity to own a Winni franchise to embark on your career in the world of cakes.</p></div>
            </div>
        </div>

        </div>

        <style>
.blog-excerpt-container{
    padding:0 20px;
    margin-top:20px;
    margin-bottom: 50px;
}

@media only screen and (max-width: 600px) {
    .blog-excerpt-container{
        padding:0;
        width: 100%;
    }
}

.blog-col {
    padding-top:10px !important;
}
.blog-title{
    font-size:16px;
}
.blog-excerpt {
    font-size: 14px;
}
.blog-excerpt p {
    margin-top:10px;
}
</style>

<div class="container blog-excerpt-container">
<div class="center" style="color:#111;font-size: 25px;margin-bottom: 10px;font-weight: 600;">
    Recommended latest reads from our Blog
</div>
<div class='row'>
    <div class='col m4 blog-col'>
            <div class="blog-title">
                <a target="_BLANK" href="celebrate-relations/7-day-countdown-to-the-perfect-mothers-day-celebration/index.html">
                    7-Day Countdown to the Perfect Mother’s Day Celebration</a>
            </div>
            <div class='blog-excerpt'>
                    <p>Mother&#8217;s Day is just around the corner. Perfect opportunity to create an amazing experience. No crazy amounts of planning required—actually the opposite! Just a simple surprise of thoughtful love each day leading up to her day.&nbsp; Your mom deserves more than a last-minute gift. She deserves a week of happiness. Let her experience the combination &hellip;</p>
</div>
        </div>
    <div class='col m4 blog-col'>
            <div class="blog-title">
                <a target="_BLANK" href="celebrate-relations/indoor-plant-care-made-easy-common-challenges-and-ways-to-tackle-them/index.html">
                    Indoor Plant Care Made Easy – Common Challenges and Ways to Tackle Them</a>
            </div>
            <div class='blog-excerpt'>
                    <p>Looking after indoor plants sounds easy—until your green buddy starts drooping, becoming yellow, or just won&#8217;t grow. You buy them hoping they’ll thrive, only to find yourself second-guessing every watering session. Don&#8217;t panic! You aren&#8217;t alone. Indoor plants can be sometimes difficult, but once you learn about the common challenges, you will find that it &hellip;</p>
</div>
        </div>
    <div class='col m4 blog-col'>
            <div class="blog-title">
                <a target="_BLANK" href="celebrate-relations/extraordinary-types-of-lilies-and-their-unique-characteristics/index.html">
                    Extraordinary Types of Lilies and Their Unique Characteristics</a>
            </div>
            <div class='blog-excerpt'>
                    <p>Lilies stand among the world&#8217;s most commonly chosen flowers because they display a combination of stunning colours and appealing forms along with captivating scents. The extensive range of Lily flower types contains distinctive specimens based on their characteristics. Let us now take a look at some specific types of lilies and why these flowers are &hellip;</p>
</div>
        </div>
    </div>
</div>
<div data-target="country-field" class="modal-trigger checkCountryName" style="color:red"><span id="messageItem"></span></div>
                                                                                </div>
                                                                                <style>
.modal-mobile-show {
    display: none
}

.borderModal {
    border-radius: 10px;
}

@media only screen and (max-width:765px) {
    .modal-desktop-show {
        display: none
    }

    .modal-mobile-show {
        display: block
    }

    .country-center-align {
        position: relative;
        bottom: 30px;
        color: black;
        font-size: 17px;
        padding-left: 15px
    }

    .coupon-modal {
        background: rgb(255, 255, 255) !important;
        overflow-x: hidden !important;
        z-index: 1003 !important;
        display: none;
        opacity: 0;
        transform: scaleX(1) scaleY(1) !important;
        top: 0% !important;
        min-height: 100vh !important;
    }

    .modal-overlay {
        position: static;
        z-index: 999;
        top: -25%;
        left: 0;
        bottom: 0;
        right: 0;
        height: 125%;
        width: 100%;
        background: #000;
        display: none;
        will-change: opacity;
    }
}

option {
    background: white;
}

.newSpaceBetween {
    display: grid;
    justify-content: center;
}


@media only screen and (max-width:765px) {
    .modal-desktop-show {
        display: none
    }

    .modal-mobile-show {
        display: block
    }

    .countrySpace .d-space a {
        pointer-events: none !important;
    }

    .countrySpace .d-space {
        padding: 0px 0 15px !important;
        width: 100% !important;
    }

    .countrySpace .d-space img {
        width: 48px;
        height: 25px;
    }

    .countrySearchInput {
        border: none !important;
    }

    .countrySelected {
        padding: 0;
    }

    #countrySelected img {
        width: 48px;
        height: 25px;
    }

    .inputBorderInternational {
        width: 100%;
        background: #ffffff;
        border: 1px solid #cacaca;
        display: flex;
        line-height: 51px;
        height: 54px !important;
        position: relative;
        border-radius: 4px 4px 0px 0px;

    }

    .contryImg {
        display: inline-block;
        vertical-align: middle;
    }

    .contryText {
        vertical-align: middle;
        display: inline-block;
        padding-left: 12px;
        font-size: 15px;
        color: #555555;
        font-weight: 600;
    }
}

.countryShowHide {
    display: none;
}

.countryBorder {
    border-bottom: 1px solid #cacaca;
    margin-bottom: 14px;
}

@media only screen and (min-width: 375px) {
    #set-left-arrow-width {
        width: 20px !important;
        font-size: 30px !important;
    }
}

.set-outside-border {
    height: auto;
    padding: 24px 24px;
    border: 1px solid #cacaca;
    border-top: none;
    margin: 0px 24px 22px;
    background: #FAFAFA 0% 0% no-repeat padding-box;
    border-radius: 0px 0px 4px 4px;
}

.countryBorder {
    border-bottom: 1px solid #cacaca;
    margin-bottom: 14px;
}

@media only screen and (max-width: 765px) {
    .d-space {
        padding: 0px 0 12px !important;
        width: 100% !important;
    }

    .d-space img {
        width: 48px;
        height: 25px;
    }
}
.user-name__saved-add_span{
font-size:18px;
}
@media screen and (min-width: 768px) {
.countrylist-modal-mobile {
    display: none;
}
}

</style>
<div class="coupon-modal modal fade borderModal" id="country-field" tabindex="0" role="dialog" >
<div class="modal-dialog">
    <div class="modal-content" style="padding: 0!important;float:left;width:100%">
        <div class="modal-desktop-show">
            <div class="modal-header" style="box-shadow: 0px 1px 2px #ddd;width: 100%;padding:25px 20px 23px; background: #f2f2f2">
                <h6 class="modal-title" id="myModalLabel" style="float: left; margin-top:-9px; text-align: center; font-size: 22px; margin-left: 32%; font-weight: 600">Select Country</h6>
                <button type="button" class="closeEvent modal-close" aria-label="Close" style="position: absolute;right: 10px; top: 4px; border:none; background: none; cursor: pointer;"><span aria-hidden="true" style="font-size:30px;">&times;</span></button>
            </div>
        </div>
          <div class="modal-header modal-mobile-show" style="position:sticky;top:0;z-index:99999;background-color: white;width: 100%; padding:0;">
            <button type="button" class=" modal-close" aria-label="Close" style="position: absolute;left: 8px;top: 21px;border:none; background: none; cursor: pointer;"><span aria-hidden="true" style="font-size:30px;"><img  class="closeEvent" alt="close-event" id="set-left-arrow-width" src="{{asset('assets/website/groot/2023/10/25/mobile/icon-feather-arrow-left.png')}}" style="width: 29px;font-size: 30px;"/> </span></button>
             <div class="selectCountryText" style="text-align:center;color:#333333;left:0;right:0;margin:0 auto;background-color: #DA0E68;height: 80px;line-height: 77px;font-size: 20px;background: transparent linear-gradient(116deg, #FFE3ED 0%, #D9F0FF 100%) 0% 0% no-repeat padding-box;">
                Select Country
             </div>
            <div style="width: 100%;padding: 0px 24px;margin-top: 34px;">
                <div class="inputBorderInternational">
                    <span style='padding: 9px;padding-left: 23px;'><img alt="icon" src="{{asset('assets/website/groot/2023/10/25/mobile/icon-material-location.png')}}" style="vertical-align:super;width:10px;font-size:30px;"/></span>
                     <input type="text" class="countrySearchInput" id="searchTheCountryList" autocomplete="off" placeholder="Search Country" style="height: 3.5rem;" >
                      <span style='padding:12px'><img  src="{{asset('assets/website/groot/2023/05/3/citysearchicons/searicon.png')}}" alt="searicon"  style="vertical-align: 10px;width:13px;font-size:30px;margin-right: 16px;"/></span>
                </div>
            </div>
          </div>
        <div class="modal-body" style=" padding: 0 ;width: 100%;float: left;height:auto;position: relative;">
            <div class="existcoupon modalWidth">
                <div class="modal-desktop-show">
                    <div class="row">
                        <div class="col s12 m12" style="padding: 10px 0 20px; font-size: 18px; color: #222; margin-top: 20px; text-align : center;">Select country where you want to send the gift.</div>
                    </div>
                    <div class="row countryListPage" style="margin:10px 20px">
                        <div class="col s4 m2 l2 d-space changeUSA newSpaceBetween" data-inr="/usa" style="cursor: pointer;">
                            <img src="{{asset('assets/website/groot/2022/06/15/international-flag/usa.png')}}" alt="USA" />
                            <div class='text country-center-align' style="margin-left: 8px;">USA</div>
                        </div>
                        <div class="col s4 m2 l2 d-space changeUK newSpaceBetween" data-inr="/uk" style="cursor: pointer;">
                            <img src="{{asset('assets/website/groot/2022/06/15/international-flag/uk.png')}}" alt="uk" />
                            <div class='text country-center-align' style="margin-left: 12px;">UK</div>
                        </div>
                        <div class="col s4 m2 l2 d-space changeUAE newSpaceBetween" data-inr="/uae" style="cursor: pointer;">
                            <img src="{{asset('assets/website/groot/2022/06/15/international-flag/uae.png')}}" alt="uae"/>
                            <div class='text country-center-align' style="margin-left: 8px;">UAE</div>
                        </div>
                        <div class="col s4 m2 l2 d-space changeAUS newSpaceBetween" data-inr="/australia" style="cursor: pointer;">
                            <img src="{{asset('assets/website/groot/2022/06/15/international-flag/australia.png')}}" alt="australia"/>
                            <div class='text country-center-align' style="margin-left: -5px;">Australia</div>
                        </div>
                        <div class="col s4 m2 l2 d-space changeCA newSpaceBetween" data-inr="/canada" style="cursor: pointer;">
                            <img src="{{asset('assets/website/groot/2022/06/15/international-flag/canada.png')}}" alt="canada" />
                            <div class='text country-center-align'>Canada</div>
                        </div>
                        <div class="col s4 m2 l2 d-space changeSIN newSpaceBetween" data-inr="/singapore" style="cursor: pointer;">
                            <img src="{{asset('assets/website/groot/2022/06/15/international-flag/singaporenew.png')}}" alt="canada" />
                            <div class='text country-center-align' style="margin-left: -10px;">Singapore</div>
                        </div>
                    </div>
                    <div class="row" style="margin : 35px 15px">
                        <div class="col s12 m12">
                            <select class=" valid nb-dropdown browser-default" id="coutryDropDown" style="background : #eee; border-radius: 5px; border: 1px solid #d7cccc" >
                                <option value="0" disabled>All Countries</option>
                                <option value='/usa'>United States</option>
                                <option value='/canada'>Canada</option>
                                <option value='/uae'>United Arab Emirates</option>
                                <option value='/uk'>United Kingdom</option>
                                <option value='/australia'>Australia</option>
                                <option value='/germany'>Germany</option>
                                <option value='/indonesia'>Indonesia</option>
                                <option value='/ireland'>Ireland</option>
                                <option value='/kuwait'>Kuwait</option>
                                <option value='/malaysia'>Malaysia</option>
                                <option value='/nepal'>Nepal</option>
                                <option value='/new-zealand'>New Zealand</option>
                                <option value='/philippines'>Philippines</option>
                                <option value='/saudi-arabia'>Saudi Arabia</option>
                                <option value='/singapore'>Singapore</option>
                                <option value='/south-africa'>South Africa</option>
                                <option value='/japan'>Japan</option>
                                <option value='/bahrain'>Bahrain</option>
                                <option value='/france'>France</option>
                            </select>
                        </div>
                    </div>
                    <div class="row m10" style="margin : 0px 12px">
                        <div class="col s12 country-center-align">
                            <a class="btn btn-primary" id="mySubmit" type="submit" style="width:100%; border-radius: 4px; background: #FF9F00 none repeat scroll 0 0; font-size: 16px; height: 48px;color:#FFF;font-weight: 400; text-align: center;text-transform: uppercase;white-space: nowrap; box-shadow: none; padding: 7px 0px; margin-bottom : 15px;" disabled>
                                <span> CONTINUE </span>
                            </a>
                        </div>
                    </div>
                </div>
                </div>
        </div>
    </div>
</div>
</div>
</div>
</div>

    <input type="hidden" id="serverCurrentHour"   value="17"/>
                  <input type="hidden" id="serverCurrentMinute"   value="12"/>
                  <input type="hidden" id="serverCurrentSecond"   value="20"/>

    <script type="application/ld+json">
        {
        "@context": "http://schema.org",
        "@type": "Organization",
        "url": "https://www.winni.in",
        "logo": "https://externalassets/groot/2024/05/21/hearts-600x292-svgtopng.png",
        "sameAs": [
        "https://www.facebook.com/WinniGifts",
        "https://www.instagram.com/winnigifts/",
        "https://www.linkedin.com/company/winni/"
        ],
        "contactPoint": [{
        "@type": "ContactPoint",
        "telephone": "+91-7829463510",
        "contactType": "customer service",
        "availableLanguage": "English"
        }]
        }

    </script>

    <script type="text/javascript">
                var webApp = {
                 getCategoryProducts: "/category-items/list",
                 getRecentlyViewProducts: "/recently-view/list",
                 };
                      </script>
<input type="hidden" id="ntCustEmail" value="">
    <input type="hidden" id="ntCustId" value="">
</main>

@endsection