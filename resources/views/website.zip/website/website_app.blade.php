<!DOCTYPE html>

<html lang="en-US">
    
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
    <meta charset="utf-8"/>
        <meta name="_csrf" content="8e6df1d8-54a3-485a-828c-afb20870ee65"/>
        <meta name="_csrf_header" content="X-XSRF-TOKEN"/>

        <link rel="preload" href="https://externalassets/coreast/constant/font/roboto/roboto-700.woff2" as="font" type="font/woff2" crossorigin>
        <link rel="preload" href="https://externalassets/coreast/constant/font/roboto/roboto-400.woff2" as="font" type="font/woff2" crossorigin>

        <link rel="dns-prefetch" href="http://d3s16h6oq3j5fb.cloudfront.net/">
        <link rel="dns-prefetch" href="http://dr56butoyblab.cloudfront.net/">
        <link rel="dns-prefetch" href="http://d3s16h6oq3j5fb.cloudfront.net/">

        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
        <title>Winni : Online Delivery of Cakes, Flowers and Gifts in India & Abroad</title>
            <meta name="description" content="Winni delivers the best cakes, flowers and gifts online covering 750+ cities in india & 40 countries around the globe. Order now to get best discounts on fresh cakes, gifts and flowers with same day, midnight & fixed time delivery options.">
            <meta property="og:description" content="Winni delivers the best cakes, flowers and gifts online covering 750+ cities in india & 40 countries around the globe. Order now to get best discounts on fresh cakes, gifts and flowers with same day, midnight & fixed time delivery options.">
        <meta name="currentCityId" content="">
            <meta name="theme-color" content="#ffffff">
        <meta name="apple-mobile-web-app-title" content="Winni">
        <meta name="application-name" content="Winni">
        <link rel="mask-icon" href="https://externalassets/coreast/constant/icon/v1/safari-pinned-tab.svg" color="#dc0013">
        <link rel="apple-touch-icon" href="{{asset('assets/website/icon/v1/apple-icon-120x120.png')}}">
        <link rel="apple-touch-icon" sizes="57x57" href="{{asset('assets/website/icon/v1/apple-icon-57x57.png')}}">
        <link rel="apple-touch-icon" sizes="60x60" href="{{asset('assets/website/icon/v1/apple-icon-60x60.png')}}">
        <link rel="apple-touch-icon" sizes="72x72" href="{{asset('assets/website/icon/v1/apple-icon-72x72.png')}}">
        <link rel="apple-touch-icon" sizes="76x76" href="{{asset('assets/website/icon/v1/apple-icon-76x76.png')}}">
        <link rel="apple-touch-icon" sizes="114x114" href="{{asset('assets/website/icon/v1/apple-icon-114x114.png')}}">
        <link rel="apple-touch-icon" sizes="120x120" href="{{asset('assets/website/icon/v1/apple-icon-120x120.png')}}">
        <link rel="apple-touch-icon" sizes="144x144" href="{{asset('assets/website/icon/v1/apple-icon-144x144.png')}}">
        <link rel="apple-touch-icon" sizes="152x152" href="{{asset('assets/website/icon/v1/apple-icon-152x152.png')}}">
        <link rel="apple-touch-icon" sizes="180x180" href="{{asset('assets/website/icon/v1/apple-icon-180x180.png')}}">
        <link rel="icon" type="image/png" sizes="192x192" href="{{asset('assets/website/icon/v1/android-icon-192x192.png')}}">
        <link rel="icon" type="image/png" sizes="32x32" href="{{asset('assets/website/icon/v1/favicon-32x32.png')}}">
        <link rel="icon" type="image/png" sizes="96x96" href="{{asset('assets/website/icon/v1/favicon-96x96.png')}}">
        <link rel="icon" type="image/png" sizes="16x16" href="{{asset('assets/website/icon/v1/favicon-16x16.png')}}">

        <link rel="manifest" href="https://externalassets/coreast/constant/manifest/08022021-3CA8E/manifest.json">

        <meta property="fb:app_id" content="262562007188964" />
        <meta property="og:type" content="website">
        <meta property="og:image" content="{{asset('assets/website/groot/2023/05/06/winni-logo/logo-test-thirty-six.png')}}">
                <meta property="og:title" content="Winni : Online Delivery of Cakes, Flowers and Gifts in India & Abroad">
            <meta property="og:site_name" content="Winni">
        <meta name="twitter:description" content="Winni delivers the best cakes, flowers and gifts online covering 750+ cities in india & 40 countries around the globe. Order now to get best discounts on fresh cakes, gifts and flowers with same day, midnight & fixed time delivery options.">
                <meta name="twitter:image" content="{{asset('assets/website/groot/2023/05/06/winni-logo/logo-test-thirty-six.png')}}">
            <meta name="twitter:card" content="summary_large_image">
        <meta name="twitter:site" content="@WinniGifts">
        <meta name="twitter:title" content="Winni : Online Delivery of Cakes, Flowers and Gifts in India & Abroad">
            <link rel="canonical" href="index.html" />
            <meta property="og:url" content="index.html" >
        <link rel="preload"  href="{{asset('assets/website/css/vnd/swiper-8.1.0.min.css')}}" as="style" onload="this.rel = 'stylesheet'"/>
        <link rel="stylesheet" href="{{asset('assets/website/css/vnd/materialize-1.0.0.min.css')}}" type="text/css"/>
        <link rel="stylesheet" href="{{asset('assets/website/css/thor/common-f0e58be5cac621b14d13d1da9a00d9f4.css')}}" type="text/css"/>
                  <link rel="stylesheet" href="{{asset('assets/website/css/thor/deliveryIn-common-2975420ce29dba92d753d73530d59335.css')}}" type="text/css"/>
                  <script>(function (w, d, s, l, i) {
                w[l] = w[l] || [];
                w[l].push({'gtm.start':
                            new Date().getTime(), event: 'gtm.js'});
                var f = d.getElementsByTagName(s)[0],
                        j = d.createElement(s), dl = l != 'dataLayer' ? '&l=' + l : '';
                j.async = true;
                j.src =
                        '../www.googletagmanager.com/gtm5445.html?id=' + i + dl;
                f.parentNode.insertBefore(j, f);
            })(window, document, 'script', 'dataLayer', 'GTM-MT9R5X3');</script>

    <noscript><iframe src="http://www.googletagmanager.com/ns.html?id=GTM-MT9R5X3"
                      height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>


       <script type="text/javascript">
                   const MIXPANEL_CUSTOM_LIB_URL = "../vision.winni.in/lib.min.js";
                   (function (f, b) { if (!b.__SV) { var e, g, i, h; window.mixpanel = b; b._i = []; b.init = function (e, f, c) { function g(a, d) { var b = d.split("."); 2 == b.length && ((a = a[b[0]]), (d = b[1])); a[d] = function () { a.push([d].concat(Array.prototype.slice.call(arguments, 0))); }; } var a = b; "undefined" !== typeof c ? (a = b[c] = []) : (c = "mixpanel"); a.people = a.people || []; a.toString = function (a) { var d = "mixpanel"; "mixpanel" !== c && (d += "." + c); a || (d += " (stub)"); return d; }; a.people.toString = function () { return a.toString(1) + ".people (stub)"; }; i = "disable time_event track track_pageview track_links track_forms track_with_groups add_group set_group remove_group register register_once alias unregister identify name_tag set_config reset opt_in_tracking opt_out_tracking has_opted_in_tracking has_opted_out_tracking clear_opt_in_out_tracking start_batch_senders people.set people.set_once people.unset people.increment people.append people.union people.track_charge people.clear_charges people.delete_user people.remove".split( " "); for (h = 0; h < i.length; h++) g(a, i[h]); var j = "set set_once union unset remove delete".split(" "); a.get_group = function () { function b(c) { d[c] = function () { call2_args = arguments; call2 = [c].concat(Array.prototype.slice.call(call2_args, 0)); a.push([e, call2]); }; } for ( var d = {}, e = ["get_group"].concat( Array.prototype.slice.call(arguments, 0)), c = 0; c < j.length; c++) b(j[c]); return d; }; b._i.push([e, f, c]); }; b.__SV = 1.2; e = f.createElement("script"); e.type = "text/javascript"; e.async = !0; e.src = "undefined" !== typeof MIXPANEL_CUSTOM_LIB_URL ? MIXPANEL_CUSTOM_LIB_URL : "file:" === f.location.protocol && "//cdn.mxpnl.com/libs/mixpanel-2-latest.min.js".match(/^\/\//) ? "https://cdn.mxpnl.com/libs/mixpanel-2-latest.min.js" : "//cdn.mxpnl.com/libs/mixpanel-2-latest.min.js"; g = f.getElementsByTagName("script")[0]; g.parentNode.insertBefore(e, g); } })(document, window.mixpanel || []);
                   mixpanel.init("6d946b9e4213ec8f7f281cf6e42fd895", {api_host: "https://vision.winni.in", track_pageview: true, persistence: 'localStorage'})
       </script>

    <script src="../www.google.com/recaptcha/enterpriseed16.js?render=6LffrDQpAAAAAAdJSbgVUcL7-4643gjXzCcIv7e1"></script>
    <script src="http://swopstore.com/wrapper.php?method=container&amp;shopId=SHOP_ID" type="text/javascript"></script>

    
<script>(window.BOOMR_mq=window.BOOMR_mq||[]).push(["addVar",{"rua.upush":"true","rua.cpush":"true","rua.upre":"true","rua.cpre":"true","rua.uprl":"false","rua.cprl":"false","rua.cprf":"false","rua.trans":"SJ-f5db48e3-63fc-4a6f-a395-66eb3e587348","rua.cook":"false","rua.ims":"false","rua.ufprl":"false","rua.cfprl":"false","rua.isuxp":"false","rua.texp":"norulematch","rua.ceh":"false","rua.ueh":"false","rua.ieh.st":"0"}]);</script>
                              <script>!function(e){var n="https://s.go-mpulse.net/boomerang/";if("False"=="True")e.BOOMR_config=e.BOOMR_config||{},e.BOOMR_config.PageParams=e.BOOMR_config.PageParams||{},e.BOOMR_config.PageParams.pci=!0,n="https://s2.go-mpulse.net/boomerang/";if(window.BOOMR_API_key="JY55S-FSH33-8QWXK-GLTX2-WSVUZ",function(){function e(){if(!o){var e=document.createElement("script");e.id="boomr-scr-as",e.src=window.BOOMR.url,e.async=!0,i.parentNode.appendChild(e),o=!0}}function t(e){o=!0;var n,t,a,r,d=document,O=window;if(window.BOOMR.snippetMethod=e?"if":"i",t=function(e,n){var t=d.createElement("script");t.id=n||"boomr-if-as",t.src=window.BOOMR.url,BOOMR_lstart=(new Date).getTime(),e=e||d.body,e.appendChild(t)},!window.addEventListener&&window.attachEvent&&navigator.userAgent.match(/MSIE [67]\./))return window.BOOMR.snippetMethod="s",void t(i.parentNode,"boomr-async");a=document.createElement("IFRAME"),a.src="about:blank",a.title="",a.role="presentation",a.loading="eager",r=(a.frameElement||a).style,r.width=0,r.height=0,r.border=0,r.display="none",i.parentNode.appendChild(a);try{O=a.contentWindow,d=O.document.open()}catch(_){n=document.domain,a.src="javascript:var d=document.open();d.domain='"+n+"';void(0);",O=a.contentWindow,d=O.document.open()}if(n)d._boomrl=function(){this.domain=n,t()},d.write("<bo"+"dy onload='document._boomrl();'>");else if(O._boomrl=function(){t()},O.addEventListener)O.addEventListener("load",O._boomrl,!1);else if(O.attachEvent)O.attachEvent("onload",O._boomrl);d.close()}function a(e){window.BOOMR_onload=e&&e.timeStamp||(new Date).getTime()}if(!window.BOOMR||!window.BOOMR.version&&!window.BOOMR.snippetExecuted){window.BOOMR=window.BOOMR||{},window.BOOMR.snippetStart=(new Date).getTime(),window.BOOMR.snippetExecuted=!0,window.BOOMR.snippetVersion=12,window.BOOMR.url=n+"JY55S-FSH33-8QWXK-GLTX2-WSVUZ";var i=document.currentScript||document.getElementsByTagName("script")[0],o=!1,r=document.createElement("link");if(r.relList&&"function"==typeof r.relList.supports&&r.relList.supports("preload")&&"as"in r)window.BOOMR.snippetMethod="p",r.href=window.BOOMR.url,r.rel="preload",r.as="script",r.addEventListener("load",e),r.addEventListener("error",function(){t(!0)}),setTimeout(function(){if(!o)t(!0)},3e3),BOOMR_lstart=(new Date).getTime(),i.parentNode.appendChild(r);else t(!1);if(window.addEventListener)window.addEventListener("load",a,!1);else if(window.attachEvent)window.attachEvent("onload",a)}}(),"".length>0)if(e&&"performance"in e&&e.performance&&"function"==typeof e.performance.setResourceTimingBufferSize)e.performance.setResourceTimingBufferSize();!function(){if(BOOMR=e.BOOMR||{},BOOMR.plugins=BOOMR.plugins||{},!BOOMR.plugins.AK){var n="true"=="true"?1:0,t="",a="eqeuby2qczpjujqacqhqabqaabucg62o-f-195e21eb6-clienttons-s.akamaihd.net",i="false"=="true"?2:1,o={"ak.v":"39","ak.cp":"1209756","ak.ai":parseInt("723849",10),"ak.ol":"0","ak.cr":159,"ak.ipv":6,"ak.proto":"http/1.1","ak.rid":"6630da08","ak.r":49692,"ak.a2":n,"ak.m":"dsca","ak.n":"essl","ak.bpcip":"2409:40e3:5016:5e9a::","ak.cport":50432,"ak.gh":"23.199.67.126","ak.quicv":"","ak.tlsv":"tls1.2","ak.0rtt":"","ak.0rtt.ed":"","ak.csrc":"-","ak.acc":"bbr","ak.t":"1747155790","ak.ak":"hOBiQwZUYzCg5VSAfCLimQ==v8ZezNWUUek9R1/0bXtUXznquwl0YTei7owXIsaxu9S3tmDe9dTOBN2MAoM6TG2Be9auc+n6g13NnDc5V7OvtpDO8XW2uyKulI57BWm1zCjCtNdjKk9ymkxQJ+P7B7wsWCr3LyU6Gs2AicaZ7n7JM12V5jVHr9iNFPFYNKXE642iNP+IoqdakmK/fPfjIR/dC8qwwLD2fK0G/D3tV7uwEsqGjPl0+QBbG/ssBOQrgY0v+AGQcALtwYZ0zTsypxUtgHONPReEis74OBUfc+UeQdOC8XgPDDX3csuz1rRKdF2h5I4u4yCFv56yylz4s0J7h+eOwcf4952haInqzSQoa6Xh1xqI55KekeX+axVuw20XvF7t27V76zwtKrtNDjdAYdTOMbBQg/AkzFgRgM4fVr3VV1GzINQGl1zgzjdX7CY=","ak.pv":"28","ak.dpoabenc":"","ak.tf":i};if(""!==t)o["ak.ruds"]=t;var r={i:!1,av:function(n){var t="http.initiator";if(n&&(!n[t]||"spa_hard"===n[t]))o["ak.feo"]=void 0!==e.aFeoApplied?1:0,BOOMR.addVar(o)},rv:function(){var e=["ak.bpcip","ak.cport","ak.cr","ak.csrc","ak.gh","ak.ipv","ak.html","ak.n","ak.ol","ak.proto","ak.quicv","ak.tlsv","ak.0rtt","ak.0rtt.ed","ak.r","ak.acc","ak-2.html","ak.tf"];BOOMR.removeVar(e)}};BOOMR.plugins.AK={akVars:o,akDNSPreFetchDomain:a,init:function(){if(!r.i){var e=BOOMR.subscribe;e("before_beacon",r.av,null,null),e("onbeacon",r.rv,null,null),r.i=!0}return this},is_complete:function(){return!0}}}}()}(window);</script></head>
<body class="city-home">
    <a name="top" id="top"></a>
    @include('website.common.header')

    @yield('content')

    <style>
    .image-alignment{
       height: 23px!important;
    }
    .text-margin{
        margin-left: 10px;
    }
    .widthForImage{
        width: 19%!important;
    }
    .title{
    margin-bottom:0px !important;
    font-weight:600;
    color: #666666;
    }
    .footerTextColor{
      color: #707070!important;
    }
    .imageWidth{
    margin-top: 20px;
    width: 8%!important;
    padding-right:4px!important;
    padding-left:4px!important;
    }
     @media screen and (min-device-width: 1366px){
        .contactWithUS{
        width: 22%!important;

        }
        .imageWidth{
              margin: 21px 7px 1px 0px;
        }
}
 @media screen and (min-device-width: 1200px) and (max-device-width: 1366px) {
  .allRight{
   font-size: 14px!important;
  }
  }
  .backgroundDesktop{
  background: #F5F5F5 0% 0% no-repeat padding-box!important;
  }
  .imageHeight{
  height: 45px!important;
  }
  .logoImageWidth{
  width:24px!important;
  }
  .textAlignment{
  vertical-align: super;
  color: #333333;
  font-weight:700
  }

</style>

<div class="footer-image-for-corporate-desktop backgroundDesktop">
    <div class="row footer-highlights margin-top-n-20 backgroundDesktop" style="max-width: 1600px; margin: 0 auto">
        <div class="col s12 m12 l4 highlight valign-wrapper">
            <div class="iconContainer left">
            <img class="responsive-img lazyload imageHeight" alt="happy-delivery-icon" src="{{asset('assets/website/groot/2023/07/19/desktop/happy-delivery.png')}}">
            </div>
            <div style="margin-top: -6px;">
                <div class="title">700+ Cities</div>
                <div class="sub-title">Happily Delivering</div>
            </div>
        </div>
        <div class="col s12 m12 l4 highlight valign-wrapper">
            <div class="iconContainer left ">
            <img  class="responsive-img lazyload"  alt="secure-payment"  src="{{asset('assets/website/groot/2023/07/19/desktop/secure-payment.png')}}" style="height: 50px;">
            </div>
            <div>
                <div class="title">100% Secure Payments</div>
                <div class="sub-title">All Major Credit & Debit Cards Accepted</div>
            </div>
        </div>
        <div class="col s12 m12 l4 valign-wrapper" style="padding:20px 18px 15px;">
            <div class="iconContainer left">
          <img class="responsive-img lazyload imageHeight" alt="customer-across"  src="{{asset('assets/website/groot/2023/07/19/desktop/customer-across-the-world.png')}}">
            </div>
            <div>
                <div class="title">20,000,000</div>
                <div class="sub-title">Customers Across The World</div>
            </div>
        </div>
    </div>
</div>


<footer class="desktop" style="background: #FAFAFA 0% 0% no-repeat">
    <div class="container">
        <div class="row" style="max-width: 100%">
            <div class="col m9 l9 s9 "  style="margin:20px 0 0 ">
                <div style class="left">
                 <img class="responsive-img lazyload" alt="logo"  src="{{asset('assets/website/groot/2023/07/19/desktop/logo.png')}}" style="max-width: 72%">
                </div>
            </div>

        </div>
        <div class="row links  adobeFooterEvent" style="margin-bottom:10px">
            <div class="col l3 s12">
                <ul style="border-right: 2px solid #dfdcdc;width:70%">
                 <li style="color: #000000;font-size:16px;font-weight:600;padding-bottom: 10px;">Our Company</li>
                    <li><a class="footerTextColor" href="about-us.html">About Us</a></li>
                    <li><a class="footerTextColor" href="careers.html">Careers</a></li>
                     <li><a class="footerTextColor" href="contact-us.html">Contact Us</a></li>
                     <li><a class="footerTextColor" href="affiliate.html">Affiliate Program</a></li>
                     <li><a class="footerTextColor" href="press.html">In News</a></li>
                </ul>
            </div>
            <div class="col l3 s12">
                <ul style="border-right: 2px solid #dfdcdc;width:70%">

                 <li style="color: #000000;font-size:16px;font-weight:600;padding-bottom: 10px;">Quick Links</li>
                <li><a class="footerTextColor" href="wishes.html">Wishes</a></li>
                <li><a class="footerTextColor" href="sitemap.html">Sitemap</a></li>
                     <li><a class="footerTextColor" href="s/customer-review.html">Customer Reviews</a></li>
                     <li><a class="footerTextColor" href="celebrate-relations/index.html">Blog - Celebrate Relations</a></li>
                   <li><a class="footerTextColor" href="corporate.html">Corporate Order</a></li>
                      <li><a class="footerTextColor" href="franchise.html">Franchise Enquiry</a></li>

                </ul>
            </div>
            <div class="col l3 s12">
                <ul>
                 <li style="color: #000000;font-size:16px;font-weight:600;padding-bottom: 10px;">Policy & Security</li>
                  <li><a class="footerTextColor" href="s/faq.html">FAQ</a></li>
                   <li><a class="footerTextColor" href="s/terms-and-conditions.html#refundPolicy">Refund Policy</a></li>
                   <li><a class="footerTextColor" href="s/privacy-policy.html">Privacy Policy</a></li>
                      <li><a class="footerTextColor" href="bug-bounty.html">Bug Bounty</a></li>
                </ul>
            </div>
            <div class="col l3 s12" style="margin-top: 38px;">
                <ul>
                     <li><a class="footerTextColor" href="data-security.html">Data Security</a></li>
                    <li><a class="footerTextColor" href="s/terms-and-conditions.html#cancelPolicy">Cancellation Policy</a></li>
                    <li><a class="footerTextColor" href="s/terms-and-conditions.html">Terms and Conditions</a></li>
                    <li><a class="footerTextColor" href="s/payments-and-security.html">Payments and Security</a></li>
                </ul>
            </div>
        </div>
    </div>
<div style="background: #F5F5F5 0% 0% no-repeat padding-box;float:left;width:100%">
    <div class="container" >
    <div class="row" style="margin-bottom:0px;margin-top: 20px;">
   <div class="col m6 l6">
                   <div class="row">
                    <div class="col m2 contactWithUS" style="margin-top: 20px;">
                         <span style="color: #0D0D0D;font-weight:600;font-size: 15px;">Connect with Us</span>
                      </div>
                       <div class="col m2 imageWidth" style="margin-top: 20px;width: 6%;">
                           <a  target="_BLANK" rel="nofollow" href="https://www.facebook.com/WinniGifts">
                               <div>
                                <img class="responsive-img lazyload logoImageWidth"  alt="facebook" src="{{asset('assets/website/groot/2023/07/19/desktop/facebook.png')}}">
                               </div>
                           </a>
                       </div>
                        <div class="col m2 imageWidth" style="  margin-left: -25px!important;width: 6%;important">
                          <a   target="_BLANK" rel="nofollow" href="https://www.instagram.com/winnigifts/">
                              <div class="">
                                  <img class="responsive-img lazyload logoImageWidth"  alt="instagram" src="{{asset('assets/website/groot/2023/07/19/desktop/instagram.png')}}">
                              </div>
                          </a>
                      </div>
                       <div class="col m2 imageWidth" style=" margin-left: -25px!important;width: 6%;important">
                           <a target="_BLANK" rel="nofollow" href="https://www.youtube.com/channel/UCsXnWQIHuO3DOr-AhtftD2w">
                               <div>
                                 <img class="responsive-img lazyload logoImageWidth" alt="youtube" src="{{asset('assets/website/groot/2023/07/19/desktop/youtube.png')}}" style="height: 24px;">
                               </div>
                           </a>
                       </div>
                        <div class="col m2 imageWidth" style="margin-left: -25px!important;width: 6%;important">
                          <a   target="_BLANK" rel="nofollow" href="https://www.linkedin.com/company/winni">
                              <div>
                                 <img class="responsive-img lazyload logoImageWidth" alt="linkdin" src="{{asset('assets/website/groot/2023/07/19/desktop/linkdin.png')}}">
                              </div>
                          </a>
                      </div>
                       <div class="col m2 imageWidth" style=" margin-left: -25px!important;width: 6%;!important">
                           <a  target="_BLANK" rel="nofollow" href="https://twitter.com/winni_gifts">
                               <div>
                                 <img class="responsive-img lazyload logoImageWidth" alt="twiter" src="{{asset('assets/website/groot/2023/12/14/desktop/twiter.png')}}">
                               </div>

                           </a>
                       </div>
                       <div class="col m2 imageWidth" style="margin-left: -25px;width: 6%;">
                          <a  target="_BLANK" rel="noopener"  href="https://www.whatsapp.com/channel/0029VaAqyET72WTsWYuAqe3Z">
                                <img class="responsive-img lazyload logoImageWidth" alt="whatsapp" src="{{asset('assets/website/groot/2024/04/23/mobile/black-whatsapp-icon.png')}}">
                          </a>
                       </div>
                   </div>

   </div>
   <div class="col m6 l6" style="margin-top: 10px;padding-left: 8%;">
   <div style="color: #333333;font-size:19px">Experience Winni on mobile</div>
   </div>
    </div>
    <div class="row allRight" style="margin-bottom: 10px;" >
    <div class="col m6 s6" style="margin-top: -15px;">
       <div style="color: #0D0D0D;font-size: 15px;">&copy; 2013 - <span >2025</span> Winni.in. All Rights Reserved</div>
    </div>
    <div class="col m6 s6" style="padding-left: 8%;">
          <div class="row" style="margin-top: -33px;">
          <div class="col s6 m4" style="padding-right: 0px;">
           <a  target="_BLANK" href="https://play.google.com/store/apps/details?id=in.winni.app&amp;referrer=utm_source%3Dwinni-website%26utm_medium%3Dweb-link">
           <img class="responsive-img lazyload" alt="google-play" src="{{asset('assets/website/groot/2023/07/19/desktop/google-play.png')}}" style="width: 86%;">
          </a>
          </div>
          <div class="col s6 m4" style="padding-left: 0px;margin-left: 27px;">
           <a  target="_BLANK" href="https://apps.apple.com/in/app/winni-cake-flowers-gifts/id1080301515">
            <img class="responsive-img lazyload" alt="app-store" src="{{asset('assets/website/groot/2023/07/19/desktop/app-store.png')}}" style="width: 86%;">
           </a>
           </div>
          </div>
        </div>
    </div>

    </div>
    </div>
    <div style="background: #E8E8E8 0% 0% no-repeat padding-box;">
      <div class="container" >
        <div class="row links  adobeFooterEvent" style="margin-bottom:0px">
             <div class="col m3 widthForImage">
                   <ul>
                       <li><a href="contact-us.html"><img class="responsive-img image-alignment" src="{{asset('assets/website/groot/2023/07/19/desktop/help.png')}}" alt="Help Center"> <span class="text-margin textAlignment" >Help Center</span></a></li>
                   </ul>
               </div>
                <div class="col m3 widthForImage">
                   <ul>
                       <li><a target="_BLANK" href="https://docs.google.com/forms/d/e/1FAIpQLScPw-OEiQkqHUA_Jrhc6DBJgAsVgkI6u9RJDgK7x3-XBsyyBQ/viewform"><img class="responsive-img image-alignment" src="{{asset('assets/website/groot/2023/07/19/desktop/vendor-tie.png')}}" alt="Vendor Tie Up"> <span class="text-margin textAlignment">Vendor Tie-ups</span></a></li>
                   </ul>
               </div>
                 <div class="col m3  widthForImage">
                   <ul>
                       <li><a href="corporate.html"><img class="responsive-img image-alignment" src="{{asset('assets/website/groot/2023/07/19/desktop/corporate-order.png')}}" alt="Corporate Order"> <span class="text-margin textAlignment">Corporate Order</span></a></li>
                   </ul>
               </div>
            <div class="col m3 widthForImage">
                <ul>
                    <li><a href="franchise.html"><img class="responsive-img image-alignment" src="{{asset('assets/website/groot/2023/07/19/desktop/franchise-enquiry.png')}}" alt="Franchise Enquiry"> <span class="text-margin textAlignment">Franchise Enquiry</span> </a></li>
                </ul>
            </div>

            <div class="col m3 widthForImage">
                <ul>
                    <li><a href="press.html"><img class="responsive-img image-alignment" src="{{asset('assets/website/groot/2023/07/19/desktop/winni-news.png')}}" alt="In News"> <span class="text-margin textAlignment"> Winni in News</span></a></li>
                </ul>
            </div>

        </div>
        </div>
        </div>

        <div style="color: #333333;text-align:center;background: #F5F5F5 0% 0% no-repeat padding-box;padding-top:25px;padding-bottom:25px"> Company Name: Dhawala Online Solutions Private Limited | CIN: U51109KA2012PTC065653 | Regd. Office Address: 3rd Floor, PLOT. NO # 128/P2, EPIP Industrial Area Whitefield,
       <div> Sonnenahalli Village, Bangalore &minus; 560066 | Contact no. +91 &minus; 7829463510 | E-mail: info@winni.in</div></div>

<input type="hidden" id="emlHsh" value=""/>
    <input type="hidden" id="mblHsh" value=""/>
    <input type="hidden" id="internaCountry" value=""/>
    <input type="hidden" id="productName" value=""/>
    <input type="hidden" id="categoryName" value=""/>
    <input type="hidden" id="totalProductsSearch" value=""/>
    <input type="hidden" id="deviceType" value="DESKTOP"/>
    <script type="text/javascript">
        var webAppLogin = {
            loginUriFooter: "/cs/customer/login",
        };
    </script>
</footer>
<script src="{{asset('assets/website/js/vnd/lazysizes-5.3.0.min.js')}}"></script>
    <script defer src="{{asset('assets/website/js/vnd/jquery-3.7.1.min.js')}}"></script>
    <script defer src="{{asset('assets/website/js/thor/adv-initialize-6efba37b6ad5b736c9eb3456d6e9fda8.js')}}"></script>
    <script defer src="{{asset('assets/website/js/vnd/materialize-1.0.1.min.js')}}"></script>
    <script defer src="{{asset('assets/website/js/thor/mixpanel-event-c97795570ecca394986fcff866d70527.js')}}"></script>


<script defer src="{{asset('assets/website/js/vnd/slick-1.8.1.min.js')}}"></script>
            <link rel="stylesheet" type="text/css" href="{{asset('assets/website/css/vnd/slick-1.8.1.min.css')}}">
        <script defer src="{{asset('assets/website/js/vnd/infinite-scroll-4.0.1.pkgd.min.js')}}"></script>
        <script defer src="{{asset('assets/website/js/vnd/swiper-8.1.0-v1.min.js')}}"></script>
        <script defer src="{{asset('assets/website/js/vnd/typeahead-0.11.1.js')}}"></script>
        <script defer src="{{asset('assets/website/js/vnd/handlebars.min-v4.7.6.js')}}"></script>
        <script defer src="{{asset('assets/website/js/vnd/money-0.2.min.js')}}"></script>
        <script defer src="{{asset('assets/website/js/vnd/accounting-0.4.2.min.js')}}"></script>
        <script defer src="{{asset('assets/website/js/thor/currency-a5b0409b390159d37b49553dfcdf42b3.js')}}"></script>
        <script defer src="{{asset('assets/website/js/thor/main-e50ebef8f68375119bf6e257b634bf07.js')}}"></script>
        <script defer type="text/javascript" src="{{asset('assets/website/js/thor/geolocation-b8d824e743030900b9edcab0dee81c94.js')}}"></script>
        <script defer src="{{asset('assets/website/js/thor/city-pincode-search-4c40a66660c72eeb4f236934611f0013.js')}}"></script>
        <script defer src="{{asset('assets/website/js/thor/homepage-5c607573095fe81ddfc6da1dde33a8d7.js')}}"></script>
	    <script>
            window.cityUrl = 'index.html';
            window.cartItemsByAjax = '/gift-box/home-xhr';
            window.searchQueryUrl = 'search/queries/%25QUERY.html';
            window.recentSearchUrl = 'search03d2.html?q=';
            window.recentViewedproductUri = '/catalog/product/recently-viewed/top';
            window.allCitiesUrl = 'app/cityName.json';
            window.changeCityUrl = 'change-city/index.html';
            window.changeCurrentCityUrl = 'xhr/change-city.html';
            window.advstit = '/advstrprcs';
            window.customerGiftcard = '/api/v2/customer-giftcard';
            window.newsFilterUri = 'news/filter/index.html';
            window.exchangemoney = {"AUD":0.0183,"AED":0.0430,"SGD":0.0152,"QAR":0.0427,"EUR":0.0104,"GBP":0.0088,"MYR":0.0503,"USD":0.0117,"CAD":0.0163,"NZD":0.0198,"INR":1.0000,"THB":0.3860};
            window.currConSymble = {"AUD":"$","AED":"د.إ","SGD":"$","QAR":"ر.ق","EUR":"€","GBP":"£","MYR":"RM","USD":"$","CAD":"$","NZD":"$","INR":"₹","THB":"฿"};
            window.saveGoogleCoordinatesUri = '/save/google/coords';
            window.setUserCityUri = '/xhr/set/user/city';
            window.checkUserPin = '/xhr/check/user/pin';
            window.setCountryUri = '/xhr/set/user/country';
            window.searchIndianCity = 'search/indianCity/queries/index.html';
            window.getCountryIdUri = '/xhr/get-country-id';
            window.searchInternationalCity = '/intern/search/location/beforeCheckout/queries';
            window.allGiftsPageUrl = 'courier-gifts.html';
            window.previousButtonUrl = 'previous/survey/question/index.html';
            window.nextButtonUrl = 'add/survey/response/index.html';
            window.finishButtonUrl = 'finish/survey/question/index.html';
			window.reviewHelpfulUrl = 'checked-helpful/index.html';
			window.fetchGeoAddressUri = '/geo/address';
			window.saveUserDemographicResponseUri = '/xhr/save/user-demographic';
			window.savedAdressedUri = '/get-address-customer';
			window.contactUsUrl = 'contact-us.html';
			window.isEnabledUserDemographic=true;
			let limeChatEnabled=false;
            
			window.isLimeChatEnabled=limeChatEnabled;
			
			window.currentCountryId=41;
</script>

<script type="text/javascript">
    dataLayer.push({
        'user_id': '',
        'crm_id': ''
    });
    const SERVER_CODES = {
        
          'INVALID_REQUEST':3001,
        
          'SESSION_EXPIRED':2001,
        
          'DELIVERY_SLOT_EXPIRED':1001,
        
    };
     const SERVER_CODES_MESSAGE = {
        2001:'session expired',
        1001:'delivery time slot expired',
        3001:'Invalid Request',
        
    };
</script>
<script type="text/javascript">window.isMobileWeb = false;</script>
	</body>

</html>
